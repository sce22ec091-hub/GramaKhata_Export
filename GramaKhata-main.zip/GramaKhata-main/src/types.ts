export type TransactionType = 'GIVE' | 'TAKE';

export interface Customer {
  id: string;
  name: string;
  phone: string;
  photoUrl?: string;
  address?: string;
  notes?: string;
  balance: number; // Positive means they owe the vendor money
  dueDate?: any; // Firestore Timestamp
  lastPaymentAt?: any; // Firestore Timestamp
  createdAt: any;
  ownerId: string;
  deleted?: boolean;
}

export interface Transaction {
  id: string;
  customerId: string;
  amount: number;
  type: TransactionType;
  note?: string;
  createdAt: any;
  ownerId: string;
}

export interface UserProfile {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
}
