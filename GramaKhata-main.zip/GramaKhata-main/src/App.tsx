import React, { useState, useEffect, useMemo } from 'react';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  doc, 
  serverTimestamp, 
  orderBy,
  runTransaction
} from 'firebase/firestore';
import { 
  Settings,
  Plus, 
  Search, 
  UserPlus, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Phone, 
  MessageCircle, 
  ChevronRight, 
  ChevronLeft,
  Camera, 
  X,
  LogOut,
  ArrowLeft,
  ArrowRight,
  Calendar,
  AlertCircle,
  Share2,
  CloudUpload,
  CheckCircle2,
  Bell,
  Edit2,
  Filter,
  History,
  TrendingUp,
  TrendingDown,
  Clock,
  QrCode,
  MoreVertical,
  Trash2,
  FileText,
  LayoutDashboard,
  BarChart3,
  PieChart as PieChartIcon,
  Wifi,
  WifiOff
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  Cell,
  PieChart,
  Pie
} from 'recharts';
import { QRCodeSVG } from 'qrcode.react';
import { auth, db, googleProvider, handleFirestoreError, OperationType } from './lib/firebase';
import { signInWithPopup, signOut, onAuthStateChanged, User, RecaptchaVerifier, signInWithPhoneNumber, ConfirmationResult, updateProfile } from 'firebase/auth';
import { Customer, Transaction, TransactionType } from './types';
import { getDocs, setDoc } from 'firebase/firestore';

import { Html5Qrcode } from 'html5-qrcode';

// --- Components ---

const AuthScreen = ({ onLogin }: { onLogin: () => void }) => {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [otp, setOtp] = useState('');
  const [confirmationResult, setConfirmationResult] = useState<ConfirmationResult | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!confirmationResult && (window as any).recaptchaVerifier === undefined) {
      (window as any).recaptchaVerifier = new RecaptchaVerifier(auth, 'sign-in-button', {
        'size': 'invisible'
      });
    }
  }, [confirmationResult]);

  const handlePhoneSignIn = async () => {
    setError('');
    setLoading(true);
    try {
      const appVerifier = (window as any).recaptchaVerifier;
      const formatPhone = phoneNumber.startsWith('+') ? phoneNumber : `+91${phoneNumber}`;
      const result = await signInWithPhoneNumber(auth, formatPhone, appVerifier);
      setConfirmationResult(result);
    } catch (err: any) {
      if (err.code === 'auth/operation-not-allowed') {
        setError("Phone Authentication is not enabled in Firebase Console. Please enable it under Authentication > Sign-in method.");
      } else {
        setError("Failed to send OTP. Please check the number.");
      }
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async () => {
    if (!confirmationResult) return;
    setError('');
    setLoading(true);
    try {
      await confirmationResult.confirm(otp);
    } catch (err: any) {
      setError("Invalid OTP code. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-gray-50 relative overflow-hidden">
      {/* Background Decor */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-100/50 rounded-full blur-3xl animate-pulse" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-indigo-100/30 rounded-full blur-3xl animate-pulse duration-1000" />
      
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-sm z-10"
      >
        <div className="bg-white p-10 rounded-[48px] shadow-2xl shadow-blue-100/50 border border-white relative">
          <div className="w-20 h-20 bg-blue-600 rounded-[28px] flex items-center justify-center mx-auto mb-8 shadow-xl shadow-blue-200 rotate-3 transform transition-hover hover:rotate-0">
            <span className="text-white text-3xl font-black">GK</span>
          </div>
          
          <div className="text-center mb-10">
            <h1 className="text-3xl font-black text-gray-900 tracking-tight mb-2">Grama-Khata</h1>
            <p className="text-sm font-bold text-gray-400 uppercase tracking-widest">Digital Baki Ledger</p>
          </div>
          
          {error && (
            <motion.div 
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              className="text-red-500 text-xs font-bold mb-6 bg-red-50 p-4 rounded-2xl flex items-center gap-3 border border-red-100"
            >
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              {error}
            </motion.div>
          )}

          {!confirmationResult ? (
            <div className="space-y-4">
              <div className="relative">
                <div className="absolute left-4 top-1/2 -translate-y-1/2 flex items-center gap-2 border-r border-gray-100 pr-3">
                  <img src="https://flagcdn.com/w20/in.png" alt="IN" className="w-4 h-3 rounded-sm" />
                  <span className="text-gray-400 font-black text-sm">+91</span>
                </div>
                <input 
                  type="tel"
                  placeholder="Mobile Number"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, '').slice(0, 10))}
                  className="w-full pl-22 pr-4 py-5 bg-gray-50 border-none rounded-2xl font-bold text-gray-700 text-lg focus:ring-4 focus:ring-blue-100 transition-all placeholder:text-gray-300 placeholder:font-medium"
                />
              </div>
              
              <button 
                id="sign-in-button"
                disabled={loading || phoneNumber.length < 10}
                onClick={handlePhoneSignIn}
                className="w-full bg-blue-600 text-white py-5 rounded-2xl font-black text-lg shadow-xl shadow-blue-100 disabled:opacity-50 active:scale-95 transition-all flex items-center justify-center gap-2"
              >
                {loading ? (
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : 'Send OTP'}
              </button>

              <div className="py-6 flex items-center gap-4">
                <div className="h-px flex-1 bg-gray-100"></div>
                <span className="text-[10px] text-gray-300 font-black uppercase tracking-[0.2em]">OR</span>
                <div className="h-px flex-1 bg-gray-100"></div>
              </div>

              <button 
                onClick={onLogin}
                className="w-full flex items-center justify-center gap-3 bg-white border-2 border-gray-50 py-5 px-6 rounded-2xl font-bold text-gray-700 shadow-sm hover:bg-gray-50 hover:border-gray-100 transition-all active:scale-95"
              >
                <img src="https://www.google.com/favicon.ico" alt="Google" className="w-5 h-5" />
                Sign in with Google
              </button>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="text-center">
                <p className="text-sm font-bold text-gray-500 mb-2">Verification Code sent to</p>
                <p className="text-lg font-black text-blue-600">+91 {phoneNumber}</p>
              </div>
              
              <div className="relative">
                <input 
                  type="text"
                  placeholder="000000"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
                  className="w-full px-4 py-6 bg-gray-50 border-none rounded-2xl text-center text-3xl font-black tracking-[0.4em] focus:ring-4 focus:ring-blue-100 transition-all placeholder:text-gray-100"
                  maxLength={6}
                />
              </div>

              <button 
                disabled={loading || otp.length < 6}
                onClick={handleVerifyOtp}
                className="w-full bg-blue-600 text-white py-5 rounded-2xl font-black text-lg shadow-xl shadow-blue-100 disabled:opacity-50 active:scale-95 transition-all"
              >
                {loading ? 'Verifying...' : 'Verify & Login'}
              </button>

              <button 
                onClick={() => setConfirmationResult(null)}
                className="w-full text-blue-600 text-sm font-black uppercase tracking-widest hover:text-blue-700 transition-colors"
              >
                Change Number
              </button>
            </div>
          )}
        </div>
        
        <p className="text-center mt-10 text-[10px] font-bold text-gray-400 uppercase tracking-[0.3em]">
          Designed for BHARAT • SECURE & FREE
        </p>
      </motion.div>
    </div>
  );
};

interface NavbarProps {
  user: User;
  backupStatus: 'idle' | 'backing-up' | 'success';
  setView: (view: 'home' | 'settings') => void;
}

const Navbar = ({ user, backupStatus, setView }: NavbarProps) => {
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return (
    <header className="sticky top-0 z-30 bg-white px-4 py-3 pb-4 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 bg-blue-600 rounded-[14px] flex items-center justify-center shadow-lg shadow-blue-100 rotate-2 cursor-pointer" onClick={() => (setView as any)('home')}>
          <span className="text-white font-black text-sm">GK</span>
        </div>
        <div>
          <h2 className="font-black text-lg text-gray-900 leading-tight">Grama-Khata</h2>
          <div className="flex items-center gap-1.5 leading-none">
            <p className="text-[8px] font-bold text-gray-400 uppercase tracking-widest leading-none">Digital Vendor Ledger</p>
            <div className={`flex items-center gap-0.5 px-1 py-0.5 rounded-full ${isOnline ? 'bg-green-50 text-green-500' : 'bg-red-50 text-red-500'}`}>
              <div className={`w-1 h-1 rounded-full ${isOnline ? 'bg-green-500' : 'bg-red-500'} animate-pulse`} />
              <span className="text-[6px] font-black uppercase tracking-tighter">{isOnline ? 'Live' : 'Off'}</span>
            </div>
          </div>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <button 
          onClick={() => (setView as any)('settings')}
          className="w-10 h-10 flex items-center justify-center bg-gray-50 rounded-2xl border border-gray-100 hover:bg-gray-100 transition-all text-gray-500 active:scale-95 group"
          title="Settings"
        >
          <Settings className="w-5 h-5 group-hover:rotate-45 transition-transform" />
        </button>

        <button 
          onClick={async () => {
            if (confirm('Are you sure you want to logout?')) {
              try {
                await signOut(auth);
              } catch (error) {
                console.error("Logout failed", error);
              }
            }
          }}
          className="flex items-center gap-2 pl-3 pr-2 py-2 bg-gray-50 rounded-2xl border border-gray-100 hover:bg-red-50 hover:border-red-100 transition-all text-gray-500 hover:text-red-600 active:scale-95 group"
          title="Logout"
        >
          <LogOut className="w-5 h-5 group-hover:translate-x-0.5 transition-transform" />
        </button>
      </div>
    </header>
  );
};

const BottomNav = ({ activeView, onSelection }: { activeView: 'home' | 'dashboard', onSelection: (v: 'home' | 'dashboard') => void }) => (
  <div className="fixed bottom-0 left-0 right-0 px-6 pb-6 z-40">
    <nav className="bg-gray-900/90 backdrop-blur-xl rounded-[32px] h-20 flex items-center justify-around px-6 border border-white/10 shadow-2xl">
      <button 
        onClick={() => onSelection('home')}
        className={`flex flex-col items-center gap-1 transition-all ${activeView === 'home' ? 'text-white' : 'text-gray-500'}`}
      >
        <div className={`p-2 transition-all ${activeView === 'home' ? 'scale-110' : ''}`}>
          <History className="w-6 h-6" />
        </div>
        <span className="text-[10px] font-black uppercase tracking-widest leading-none">Ledger</span>
      </button>

      <button 
        onClick={() => onSelection('dashboard')}
        className={`flex flex-col items-center gap-1 transition-all ${activeView === 'dashboard' ? 'text-white' : 'text-gray-500'}`}
      >
        <div className={`p-2 transition-all ${activeView === 'dashboard' ? 'scale-110' : ''}`}>
          <LayoutDashboard className="w-6 h-6" />
        </div>
        <span className="text-[10px] font-black uppercase tracking-widest leading-none">Stats</span>
      </button>
    </nav>
  </div>
);

interface CustomerCardProps {
  customer: Customer;
  onClick: () => void;
  onFollowUp: (e: React.MouseEvent) => void;
  preferences: { compactView: boolean; confirmDelete: boolean };
}

const CustomerCard: React.FC<CustomerCardProps> = ({ 
  customer, 
  onClick, 
  onFollowUp,
  preferences
}) => {
  const isDue = customer.balance > 0;
  
  return (
    <motion.div 
      layout
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className={`${preferences.compactView ? 'p-2.5' : 'p-4'} rounded-2xl flex items-center gap-4 transition-all relative cursor-pointer bg-white border-gray-50 shadow-sm border`}
    >
      <div className="relative">
        <div className={`${preferences.compactView ? 'w-10 h-10' : 'w-14 h-14'} rounded-full bg-gray-100 overflow-hidden flex items-center justify-center border-2 border-white shadow-sm`}>
          {customer.photoUrl ? (
            <img src={customer.photoUrl} alt={customer.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
          ) : (
            <span className={`${preferences.compactView ? 'text-lg' : 'text-xl'} text-gray-400 font-bold uppercase`}>{customer.name.charAt(0)}</span>
          )}
        </div>
        {isDue && (
          <div className={`absolute -top-1 -right-1 ${preferences.compactView ? 'w-3 h-3' : 'w-4 h-4'} bg-red-500 border-2 border-white rounded-full`} />
        )}
      </div>
      <div className="flex-1 min-w-0">
        <h3 className={`font-bold text-gray-900 truncate ${preferences.compactView ? 'text-base' : 'text-lg'}`}>{customer.name}</h3>
        <p className={`${preferences.compactView ? 'text-xs' : 'text-sm'} text-gray-500`}>{customer.phone}</p>
      </div>
      <div className="text-right">
        <p className={`font-bold ${preferences.compactView ? 'text-base' : 'text-lg'} ${isDue ? 'text-red-500' : 'text-green-500'}`}>
          ₹{Math.abs(customer.balance)}
        </p>
        <div className="flex items-center justify-end gap-2">
          <p className="text-[10px] uppercase font-bold text-gray-400 tracking-wider">
            {isDue ? 'DUE' : 'ADVANCE'}
          </p>
          {customer.dueDate && isDue && (
            <div className={`p-1 rounded-md flex items-center gap-1 ${ensureDate(customer.dueDate) < new Date() ? 'bg-red-100 text-red-600' : 'bg-blue-100 text-blue-600'}`}>
              <Clock className="w-3 h-3" />
              <span className="text-[10px] font-bold">{ensureDate(customer.dueDate).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}</span>
            </div>
          )}
          {isDue && (
            <button 
              onClick={onFollowUp}
              className="p-1.5 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors"
            >
              <MessageCircle className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
      <ChevronRight className="w-5 h-5 text-gray-300" />
    </motion.div>
  );
};

interface TransactionItemProps {
  tx: Transaction;
  onDelete?: (id: string) => void;
}

const TransactionItem: React.FC<TransactionItemProps> = ({ tx, onDelete }) => {
  const isGive = tx.type === 'GIVE';
  const date = ensureDate(tx.createdAt);

  return (
    <div className="group flex items-center gap-4 py-4 border-b border-gray-50 last:border-0 relative">
      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${isGive ? 'bg-red-50 text-red-500' : 'bg-green-50 text-green-500'}`}>
        {isGive ? <ArrowUpRight className="w-5 h-5" /> : <ArrowDownLeft className="w-5 h-5" />}
      </div>
      <div className="flex-1 truncate">
        <div className="flex items-center gap-2">
          <p className="font-semibold text-gray-800">{tx.note || (isGive ? 'Borrowed' : 'Paid')}</p>
          {onDelete && (
            <button 
              onClick={(e) => {
                e.stopPropagation();
                onDelete(tx.id);
              }}
              className="opacity-0 group-hover:opacity-100 p-1 text-gray-300 hover:text-red-500 transition-all font-bold"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
        <p className="text-xs text-gray-400">{date.toLocaleDateString()} • {date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
      </div>
      <div className={`font-bold ${isGive ? 'text-red-500' : 'text-green-500'}`}>
        {isGive ? '-' : '+'} ₹{tx.amount}
      </div>
    </div>
  );
};

// --- Helpers ---

const ensureDate = (dateVal: any): Date => {
  if (!dateVal) return new Date();
  if (typeof dateVal.toDate === 'function') return dateVal.toDate();
  if (dateVal instanceof Date) return dateVal;
  if (dateVal.seconds) return new Date(dateVal.seconds * 1000);
  return new Date(dateVal);
};

// --- Main App ---

export default function App() {
  console.log("Render Start");
  
  useEffect(() => {
    return () => {
      console.log("Render End");
    };
  }, []);

  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDueDateModal, setShowDueDateModal] = useState(false);
  const [showSummaryModal, setShowSummaryModal] = useState(false);
  const [showMoreActions, setShowMoreActions] = useState(false);

  const deleteCustomer = async (id: string) => {
    if (!user) return;
    if (preferences.confirmDelete && !confirm('Are you sure you want to delete this customer? This will hide all their data.')) return;
    try {
      setBackupStatus('backing-up');
      await updateDoc(doc(db, 'customers', id), {
        deleted: true,
        updatedAt: serverTimestamp()
      });
      setSelectedCustomer(null);
      setBackupStatus('success');
      setTimeout(() => setBackupStatus('idle'), 2000);
    } catch (err) {
      console.error("Delete failed", err);
      setBackupStatus('idle');
    }
  };
  const [showTxModal, setShowTxModal] = useState<'GIVE' | 'TAKE' | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'balance' | 'name'>('balance');
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [view, setView] = useState<'home' | 'settings' | 'dashboard'>('home');
  const [backupStatus, setBackupStatus] = useState<'idle' | 'backing-up' | 'success'>('idle');
  const [preferences, setPreferences] = useState({
    confirmDelete: localStorage.getItem('pref_confirm_delete') !== 'false',
    compactView: localStorage.getItem('pref_compact_view') === 'true',
  });
  const [upiId, setUpiId] = useState('');
  const [reminderTemplate, setReminderTemplate] = useState('Namaskara {name}, this is a reminder for your outstanding balance of ₹{balance}. Dhanyavadagalu!');
  const [shopName, setShopName] = useState('');
  const [isEditingName, setIsEditingName] = useState(false);

  useEffect(() => {
    if (user) {
      setShopName(user.displayName || '');
      setUpiId(localStorage.getItem(`upi_id_${user.uid}`) || '');
      setReminderTemplate(localStorage.getItem(`reminder_template_${user.uid}`) || 'Namaskara {name}, this is a reminder for your outstanding balance of ₹{balance}. Dhanyavadagalu!');
    }
  }, [user]);

  const handleUpdateProfile = async () => {
    if (!user) return;
    try {
      await updateProfile(user, { displayName: shopName });
      setIsEditingName(false);
    } catch (error) {
      console.error("Profile update failed", error);
    }
  };

  const [showQrModal, setShowQrModal] = useState(false);
  const [showScanner, setShowScanner] = useState(false);

  const handleSingleSettle = async (customer: Customer) => {
    if (!user || customer.balance <= 0) return;
    
    setBackupStatus('backing-up');
    try {
      const customerRef = doc(db, 'customers', customer.id);
      const amount = customer.balance;

      await runTransaction(db, async (transaction) => {
        const snap = await transaction.get(customerRef);
        if (!snap.exists()) return;

        transaction.update(customerRef, {
          balance: 0,
          lastPaymentAt: serverTimestamp()
        });

        const newTxRef = doc(collection(db, 'customers', customer.id, 'transactions'));
        transaction.set(newTxRef, {
          customerId: customer.id,
          amount,
          type: 'TAKE',
          note: 'Full Settlement',
          createdAt: serverTimestamp(),
          ownerId: user.uid
        });
      });
      
      setSelectedCustomer(prev => prev ? { ...prev, balance: 0 } : null);
      setBackupStatus('success');
      setTimeout(() => setBackupStatus('idle'), 3000);
    } catch (err) {
      console.error("Settlement failed", err);
      setBackupStatus('idle');
    }
  };

  useEffect(() => {
    return onAuthStateChanged(auth, (u) => {
      setUser(u);
      setLoading(false);
      if (u) {
        checkAndPerformBackup(u);
      }
    });
  }, []);

  const [lastBackupTime, setLastBackupTime] = useState<string | null>(null);

  useEffect(() => {
    if (user) {
      setLastBackupTime(localStorage.getItem(`last_backup_${user.uid}`));
    }
  }, [user]);

  const performBackup = async (u: User, isManual = false) => {
    setBackupStatus('backing-up');
    try {
      // Fetch snapshot of active customers
      const custSnap = await getDocs(query(collection(db, 'customers'), where('ownerId', '==', u.uid)));
      const customersData = custSnap.docs
        .map(d => ({ id: d.id, ...d.data() }))
        .filter((c: any) => !c.deleted);
      
      // For a more complete backup, we could iterate transactions, 
      // but for size limits in Firestore we'll just backup customer metadata + current balances
      const backupPayload = {
        customers: customersData,
        backupDate: new Date().toISOString(),
        version: '1.1',
        shopName: u.displayName || 'Unnamed Shop'
      };
      
      await setDoc(doc(collection(db, 'backups', u.uid, 'snapshots')), {
        data: JSON.stringify(backupPayload),
        createdAt: serverTimestamp(),
        type: isManual ? 'manual' : 'automatic'
      });

      const now = Date.now().toString();
      localStorage.setItem(`last_backup_${u.uid}`, now);
      setLastBackupTime(now);
      setBackupStatus('success');
      setTimeout(() => setBackupStatus('idle'), 3000);
      return true;
    } catch (err) {
      console.error("Backup failed", err);
      setBackupStatus('idle');
      return false;
    }
  };

  const checkAndPerformBackup = async (u: User) => {
    const lastBackup = localStorage.getItem(`last_backup_${u.uid}`);
    const now = Date.now();
    const dayInMs = 24 * 60 * 60 * 1000;

    if (!lastBackup || now - parseInt(lastBackup) > dayInMs) {
      await performBackup(u, false);
    }
  };

  useEffect(() => {
    if (!user) {
      setCustomers([]);
      return;
    }

    const q = query(
      collection(db, 'customers'),
      where('ownerId', '==', user.uid),
      orderBy('balance', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs
        .map(doc => ({ id: doc.id, ...doc.data() } as Customer))
        .filter(c => !c.deleted);
      setCustomers(docs);
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'customers'));

    return unsubscribe;
  }, [user]);

  useEffect(() => {
    if (!selectedCustomer || !user) {
      setTransactions([]);
      return;
    }

    const q = query(
      collection(db, 'customers', selectedCustomer.id, 'transactions'),
      where('ownerId', '==', user.uid),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Transaction));
      setTransactions(docs);
    }, (err) => handleFirestoreError(err, OperationType.LIST, `customers/${selectedCustomer.id}/transactions`));

    return unsubscribe;
  }, [selectedCustomer, user]);

  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error("Login failed", error);
    }
  };

  const filteredCustomers = useMemo(() => {
    return customers
      .filter(c => 
        c.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        c.phone.includes(searchQuery)
      )
      .sort((a, b) => {
        if (sortBy === 'balance') return b.balance - a.balance;
        return a.name.localeCompare(b.name);
      });
  }, [customers, searchQuery, sortBy]);

  const stats = useMemo(() => {
    const totalDue = customers.reduce((sum, c) => sum + (c.balance > 0 ? c.balance : 0), 0);
    const totalAdvance = customers.reduce((sum, c) => sum + (c.balance < 0 ? Math.abs(c.balance) : 0), 0);
    return { totalDue, totalAdvance };
  }, [customers]);

  const addTransaction = async (type: TransactionType, amount: number, note: string) => {
    if (!selectedCustomer || !user) return;

    try {
      const txData: any = {
        customerId: selectedCustomer.id,
        amount,
        type,
        createdAt: serverTimestamp(),
        ownerId: user.uid
      };

      if (note) {
        txData.note = note;
      }

      // Atomic update of balance
      await runTransaction(db, async (transaction) => {
        const customerRef = doc(db, 'customers', selectedCustomer.id);
        const customerSnap = await transaction.get(customerRef);
        
        if (!customerSnap.exists()) throw new Error("Customer not found");
        
        const currentBalance = customerSnap.data()?.balance || 0;
        const newBalance = type === 'GIVE' ? currentBalance + amount : currentBalance - amount;
        
        const updateData: any = { balance: newBalance };
        if (type === 'TAKE') {
          updateData.lastPaymentAt = serverTimestamp();
        } else if (customerSnap.data()?.lastPaymentAt) {
          updateData.lastPaymentAt = customerSnap.data()?.lastPaymentAt;
        }
        
        transaction.update(customerRef, updateData);

        const newTxRef = doc(collection(db, 'customers', selectedCustomer.id, 'transactions'));
        transaction.set(newTxRef, txData);
      });

      setShowTxModal(null);

      // Send WhatsApp (Simulated/Deep link)
      const msg = `Namaskara ${selectedCustomer.name}, an entry of ₹${amount} (${type === 'GIVE' ? 'Credit' : 'Payment'}) was made at Our Shop. New balance: ₹${Math.abs(selectedCustomer.balance + (type === 'GIVE' ? amount : -amount))}`;
      const url = `https://wa.me/${selectedCustomer.phone.replace(/\D/g, '')}?text=${encodeURIComponent(msg)}`;
      window.open(url, '_blank');

    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'transaction');
    }
  };

  const handleUpdateCustomer = async (data: { name: string, phone: string, address?: string, notes?: string, photoUrl?: string }) => {
    if (!selectedCustomer) return;
    try {
      const customerRef = doc(db, 'customers', selectedCustomer.id);
      const updateData: any = {
        name: data.name,
        phone: data.phone,
        address: data.address || '',
        notes: data.notes || ''
      };
      if (data.photoUrl) updateData.photoUrl = data.photoUrl;
      
      await updateDoc(customerRef, updateData);
      setSelectedCustomer({ ...selectedCustomer, ...updateData });
      setShowEditModal(false);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `customers/${selectedCustomer.id}`);
    }
  };

  const handleSetDueDate = async (date: Date) => {
    if (!selectedCustomer) return;
    try {
      const customerRef = doc(db, 'customers', selectedCustomer.id);
      await updateDoc(customerRef, { dueDate: date });
      setSelectedCustomer({ ...selectedCustomer, dueDate: date });
      setShowDueDateModal(false);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `customers/${selectedCustomer.id}`);
    }
  };

  const handleDeleteTransaction = async (txId: string) => {
    if (!selectedCustomer || !user) return;
    const tx = transactions.find(t => t.id === txId);
    if (!tx) return;

    if (preferences.confirmDelete && !confirm('Delete this transaction? The customer balance will be adjusted.')) return;

    try {
      setBackupStatus('backing-up');
      const customerRef = doc(db, 'customers', selectedCustomer.id);

      await runTransaction(db, async (transaction) => {
        const custSnap = await transaction.get(customerRef);
        if (!custSnap.exists()) return;

        const currentBalance = custSnap.data()?.balance || 0;
        const balanceChange = tx.type === 'GIVE' ? -tx.amount : tx.amount;
        
        transaction.update(customerRef, {
          balance: currentBalance + balanceChange,
          updatedAt: serverTimestamp()
        });
        
        const txRef = doc(db, 'customers', selectedCustomer.id, 'transactions', txId);
        transaction.delete(txRef);
      });

      setBackupStatus('success');
      setTimeout(() => setBackupStatus('idle'), 2000);
    } catch (err) {
      console.error("Delete transaction failed", err);
      setBackupStatus('idle');
    }
  };

  const handleFollowUp = (customer: Customer, e: React.MouseEvent) => {
    e.stopPropagation();
    const msg = `Namaskara ${customer.name}, a gentle reminder about your outstanding balance of ₹${customer.balance} at our shop. Please settle it when possible. Dhanyavadagalu!`;
    const url = `https://wa.me/${customer.phone.replace(/\D/g, '')}?text=${encodeURIComponent(msg)}`;
    window.open(url, '_blank');
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center">Loading...</div>;

  if (!user) return <AuthScreen onLogin={handleLogin} />;

  if (view === 'settings') {
    return (
      <div className="max-w-md mx-auto min-h-screen bg-gray-50 flex flex-col">
        <div className="p-4 flex items-center gap-4 bg-white border-b border-gray-100">
          <button onClick={() => setView('home')} className="p-2 -ml-2 text-gray-500">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h2 className="text-xl font-bold">Settings & Profile</h2>
        </div>
        <main className="flex-1 overflow-y-auto p-6 space-y-6">
          <div className="flex flex-col items-center py-8 bg-white rounded-[40px] shadow-sm border border-gray-100">
            <div className="relative mb-4">
              <div className="w-28 h-28 rounded-[32px] bg-blue-100 flex items-center justify-center text-blue-600 border-4 border-white shadow-xl">
                {user.photoURL ? (
                  <img src={user.photoURL} alt="Profile" className="w-full h-full rounded-[28px] object-cover" />
                ) : (
                  <span className="text-4xl font-black">{shopName?.[0] || 'V'}</span>
                )}
              </div>
              <div className="absolute -bottom-2 -right-2 w-10 h-10 bg-blue-600 text-white rounded-2xl flex items-center justify-center border-4 border-white shadow-lg">
                <Camera className="w-4 h-4" />
              </div>
            </div>
            
            {!isEditingName ? (
              <div className="flex flex-col items-center">
                <div className="flex items-center gap-2">
                  <h3 className="text-2xl font-black text-gray-900">{shopName || 'Grama-Khata Shop'}</h3>
                  <button onClick={() => setIsEditingName(true)} className="p-1 text-gray-300 hover:text-blue-500">
                    <Edit2 className="w-4 h-4" />
                  </button>
                </div>
                <p className="text-gray-500 font-medium">{user.phoneNumber || user.email}</p>
              </div>
            ) : (
              <div className="flex flex-col items-center w-full px-8 gap-3">
                <input 
                  type="text"
                  value={shopName}
                  onChange={(e) => setShopName(e.target.value)}
                  placeholder="Enter Shop Name"
                  className="w-full text-center bg-gray-50 py-3 rounded-2xl border-none font-bold text-xl focus:ring-2 focus:ring-blue-100"
                  autoFocus
                />
                <div className="flex gap-2 w-full">
                  <button onClick={() => setIsEditingName(false)} className="flex-1 py-3 text-gray-500 font-bold">Cancel</button>
                  <button onClick={handleUpdateProfile} className="flex-1 py-3 bg-blue-600 text-white rounded-2xl font-bold shadow-lg">Save</button>
                </div>
              </div>
            )}
          </div>

          <div className="space-y-4">
            <div className="bg-white p-6 rounded-[32px] shadow-sm border border-gray-100">
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-4 flex items-center justify-between">
                Cloud Backup Status
                {backupStatus === 'backing-up' && <span className="text-blue-500 animate-pulse text-[8px]">Syncing...</span>}
              </p>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl bg-blue-50 flex items-center justify-center text-blue-600">
                  <CloudUpload className="w-6 h-6" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-bold text-gray-700">Auto-Backup Enabled</span>
                    <span className="bg-green-100 text-green-600 text-[8px] px-2 py-0.5 rounded-full font-black">ACTIVE</span>
                  </div>
                  <p className="text-[10px] text-gray-400">
                    {lastBackupTime ? `Last synced: ${new Date(parseInt(lastBackupTime)).toLocaleString()}` : 'Never synced to cloud'}
                  </p>
                </div>
              </div>
              <button 
                onClick={() => user && performBackup(user, true)}
                disabled={backupStatus === 'backing-up'}
                className="w-full mt-4 py-3 bg-gray-50 text-blue-600 rounded-2xl font-bold text-xs hover:bg-blue-50 transition-colors flex items-center justify-center gap-2 border border-blue-50"
              >
                {backupStatus === 'backing-up' ? 'Syncing...' : 'Backup Now to Cloud Storage'}
              </button>
            </div>

            <div className="bg-white p-6 rounded-[32px] shadow-sm border border-gray-100">
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-4">Payment Settings</p>
              <div className="flex flex-col gap-4">
                <div>
                  <label className="text-xs font-bold text-gray-500 ml-1">YOUR UPI ID</label>
                  <div className="mt-1 relative">
                    <input 
                      type="text"
                      placeholder="e.g. name@paytm"
                      value={upiId}
                      onChange={(e) => {
                        setUpiId(e.target.value);
                        localStorage.setItem(`upi_id_${user.uid}`, e.target.value);
                      }}
                      className="w-full bg-gray-50 py-4 px-4 rounded-2xl border-none font-bold text-blue-600 focus:ring-2 focus:ring-blue-100 placeholder:font-normal placeholder:text-gray-300"
                    />
                  </div>
                  <p className="text-[10px] text-gray-400 mt-2 px-1">This ID will be used for auto-generating payment reminders and QR codes for your customers.</p>
                  
                  {upiId && (
                    <div className="mt-6 flex flex-col items-center p-8 bg-white rounded-[40px] border border-blue-100 shadow-xl shadow-blue-500/5 transition-all hover:scale-[1.02]">
                      <div className="bg-white p-6 rounded-3xl shadow-lg mb-4 border-2 border-gray-50 flex items-center justify-center">
                        <QRCodeSVG 
                          value={`upi://pay?pa=${upiId}&pn=${encodeURIComponent(shopName || 'Vendor')}&cu=INR`} 
                          size={180}
                          level="H"
                        />
                      </div>
                      <p className="text-[12px] font-black text-gray-900 uppercase tracking-[0.2em] text-center mb-1">Business Payment QR</p>
                      <p className="text-[10px] text-blue-600 font-bold bg-blue-50 px-3 py-1 rounded-full">{upiId}</p>
                      
                      <button 
                        onClick={() => {
                          const link = `upi://pay?pa=${upiId}&pn=${encodeURIComponent(shopName || 'Vendor')}&cu=INR`;
                          if (navigator.share) {
                            navigator.share({
                              title: `${shopName} Payment QR`,
                              text: `Pay to ${shopName} using this UPI link:`,
                              url: link
                            }).catch(err => console.error(err));
                          } else {
                            navigator.clipboard.writeText(link);
                            alert('Payment link copied to clipboard!');
                          }
                        }}
                        className="mt-6 flex items-center gap-2 px-6 py-3 bg-gray-900 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-black active:scale-95 transition-all shadow-lg"
                      >
                        <QrCode className="w-4 h-4" />
                        Share / Export QR
                      </button>
                    </div>
                  )}
                </div>

                <div>
                  <label className="text-xs font-bold text-gray-500 ml-1">REMINDER TEMPLATE</label>
                  <div className="mt-1 relative">
                    <textarea 
                      value={reminderTemplate}
                      onChange={(e) => {
                        setReminderTemplate(e.target.value);
                        localStorage.setItem(`reminder_template_${user.uid}`, e.target.value);
                      }}
                      className="w-full bg-gray-50 py-4 px-4 rounded-2xl border-none font-medium text-gray-700 focus:ring-2 focus:ring-blue-100 placeholder:text-gray-300 resize-none"
                      rows={4}
                    />
                  </div>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {['{name}', '{balance}', '{shop}'].map(tag => (
                      <span key={tag} className="text-[10px] bg-blue-50 text-blue-500 px-2 py-1 rounded-md font-bold">{tag}</span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white p-6 rounded-[32px] shadow-sm border border-gray-100">
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-4">App Preferences</p>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-bold text-gray-700">Confirm on Delete</p>
                    <p className="text-[10px] text-gray-400">Ask before deleting customers or transactions</p>
                  </div>
                  <button 
                    onClick={() => {
                      const newValue = !preferences.confirmDelete;
                      setPreferences(prev => ({ ...prev, confirmDelete: newValue }));
                      localStorage.setItem('pref_confirm_delete', String(newValue));
                    }}
                    className={`w-12 h-6 rounded-full transition-colors relative ${preferences.confirmDelete ? 'bg-blue-600' : 'bg-gray-200'}`}
                  >
                    <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${preferences.confirmDelete ? 'left-7' : 'left-1'}`} />
                  </button>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-bold text-gray-700">Compact List View</p>
                    <p className="text-[10px] text-gray-400">Show more customers on one screen</p>
                  </div>
                  <button 
                    onClick={() => {
                      const newValue = !preferences.compactView;
                      setPreferences(prev => ({ ...prev, compactView: newValue }));
                      localStorage.setItem('pref_compact_view', String(newValue));
                    }}
                    className={`w-12 h-6 rounded-full transition-colors relative ${preferences.compactView ? 'bg-blue-600' : 'bg-gray-200'}`}
                  >
                    <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${preferences.compactView ? 'left-7' : 'left-1'}`} />
                  </button>
                </div>
              </div>
            </div>

            <div className="bg-white p-6 rounded-[32px] shadow-sm border border-gray-100">
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-4">Account Information</p>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-500 font-medium">Business Email</span>
                  <span className="text-sm font-bold text-gray-800">{user.email || 'Not connected'}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-500 font-medium">Phone Auth</span>
                  <span className="text-sm font-bold text-gray-800">{user.phoneNumber || 'Not linked'}</span>
                </div>
                <div className="pt-4 border-t border-gray-50 flex justify-between items-center">
                  <span className="text-xs text-gray-400 font-bold uppercase">Account ID</span>
                  <span className="text-[10px] font-mono text-gray-300 truncate max-w-[150px]">{user.uid}</span>
                </div>
              </div>
            </div>

            <button 
              onClick={async () => {
                try {
                  await signOut(auth);
                  setView('home');
                } catch (error) {
                  console.error("Logout failed", error);
                }
              }}
              className="w-full flex items-center justify-center gap-3 bg-white text-red-500 py-6 rounded-[32px] font-black border-2 border-red-50 hover:bg-red-50 transition-all active:scale-95 shadow-sm"
            >
              <LogOut className="w-5 h-5" />
              Sign Out from Grama-Khata
            </button>
          </div>

          <p className="text-center text-[10px] font-bold text-gray-300 uppercase tracking-[0.2em] pt-8">
            v1.0.4 • Grama-Khata Digital
          </p>
        </main>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto min-h-screen bg-gray-50 flex flex-col relative font-sans">
      <Navbar 
        user={user} 
        backupStatus={backupStatus} 
        setView={setView}
      />
      
      {!selectedCustomer ? (
        <>
          {view === 'dashboard' ? (
            <DashboardView customers={customers} />
          ) : (
            <main className="flex-1 overflow-y-auto p-4 space-y-6 pb-40">
              {/* Summary */}
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-red-50 p-6 rounded-[32px] border border-red-100/50 shadow-sm shadow-red-100/20">
                  <p className="text-[10px] font-black text-red-400 uppercase tracking-[0.2em] mb-1">TOTAL DUE</p>
                  <h3 className="text-2xl font-black text-red-600">₹{stats.totalDue.toLocaleString()}</h3>
                </div>
                <div className="bg-green-50 p-6 rounded-[32px] border border-green-100/50 shadow-sm shadow-green-100/20">
                  <p className="text-[10px] font-black text-green-400 uppercase tracking-[0.2em] mb-1">ADVANCE</p>
                  <h3 className="text-2xl font-black text-green-600">₹{stats.totalAdvance.toLocaleString()}</h3>
                </div>
              </div>

              {/* Search */}
              <div className="relative group">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5 group-focus-within:text-blue-500 transition-colors" />
                <input 
                  type="text" 
                  placeholder="Search name or phone number..." 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-white py-5 pl-12 pr-12 rounded-3xl border-2 border-transparent shadow-sm focus:border-blue-100 focus:ring-4 focus:ring-blue-50 transition-all font-medium text-gray-700"
                />
                {searchQuery && (
                  <button 
                    onClick={() => setSearchQuery('')}
                    className="absolute right-4 top-1/2 -translate-y-1/2 p-1 bg-gray-100 text-gray-400 rounded-full hover:bg-gray-200 hover:text-gray-600 transition-all"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>

              {/* List */}
              <div className="space-y-3">
                <div className="flex items-center justify-between px-1">
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-gray-400 text-[10px] uppercase tracking-widest">
                      {searchQuery ? `${filteredCustomers.length} RESULTS` : `${customers.length} CUSTOMERS`}
                    </h3>
                    {searchQuery && (
                      <span className="bg-blue-100 text-blue-600 text-[8px] font-black px-1.5 py-0.5 rounded-full uppercase">FILTERED</span>
                    )}
                  </div>
                  <button 
                    onClick={() => setSortBy(sortBy === 'balance' ? 'name' : 'balance')}
                    className="text-blue-600 text-xs font-bold flex items-center gap-1 bg-white px-3 py-1 rounded-full shadow-sm border border-gray-50 active:scale-95 transition-all"
                  >
                    <Filter className="w-3 h-3" />
                    {sortBy === 'balance' ? 'By Name' : 'By Due'}
                  </button>
                </div>
                <AnimatePresence mode="popLayout">
                  {filteredCustomers.map(customer => (
                    <CustomerCard 
                      key={customer.id} 
                      customer={customer} 
                      onClick={() => setSelectedCustomer(customer)} 
                      onFollowUp={(e) => handleFollowUp(customer, e)}
                      preferences={preferences}
                    />
                  ))}
                </AnimatePresence>
                {filteredCustomers.length === 0 && (
                  <div className="text-center py-20">
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Search className="w-8 h-8 text-gray-300" />
                    </div>
                    <p className="text-gray-400 font-medium">No customers found</p>
                  </div>
                )}
              </div>
            </main>
          )}

          {/* Floating Action Button */}
          <div className="fixed bottom-32 right-6 flex flex-col gap-4 z-40">
            {view === 'home' && (
              <>
                <button 
                  onClick={() => setShowScanner(true)}
                  className="w-14 h-14 bg-white text-blue-600 rounded-full shadow-lg border border-gray-100 flex items-center justify-center active:scale-95 transition-transform"
                >
                  <QrCode className="w-6 h-6" />
                </button>
                <button 
                  onClick={() => setShowAddModal(true)}
                  className="w-16 h-16 bg-blue-600 text-white rounded-full shadow-lg shadow-blue-200 flex items-center justify-center active:scale-95 transition-transform"
                >
                  <UserPlus className="w-8 h-8" />
                </button>
              </>
            )}
          </div>

          <BottomNav 
            activeView={view === 'dashboard' ? 'dashboard' : 'home'} 
            onSelection={(v) => setView(v)} 
          />
        </>
      ) : (() => {
        const idx = filteredCustomers.findIndex(c => c.id === selectedCustomer.id);
        return (
          <CustomerDetail 
            customer={selectedCustomer} 
            transactions={transactions}
            onBack={() => setSelectedCustomer(null)} 
            onNext={idx < filteredCustomers.length - 1 ? () => setSelectedCustomer(filteredCustomers[idx + 1]) : undefined}
            onPrev={idx > 0 ? () => setSelectedCustomer(filteredCustomers[idx - 1]) : undefined}
            onAction={(type) => setShowTxModal(type)}
            onEdit={() => setShowEditModal(true)}
            onSummary={() => setShowSummaryModal(true)}
            onSetDueDate={() => setShowDueDateModal(true)}
            onSettle={() => handleSingleSettle(selectedCustomer)}
            onDelete={() => {
              deleteCustomer(selectedCustomer.id);
            }}
            onDeleteTransaction={handleDeleteTransaction}
            upiId={upiId}
            reminderTemplate={reminderTemplate}
            shopName={shopName}
            onScanOpen={() => setShowScanner(true)}
          />
        );
      })()}

      {/* Modals */}
      <AnimatePresence>
        {showSummaryModal && selectedCustomer && (
          <TransactionSummaryModal 
            transactions={transactions} 
            customerName={selectedCustomer.name}
            onClose={() => setShowSummaryModal(false)} 
          />
        )}
        {showDueDateModal && selectedCustomer && (
          <SetDueDateModal 
            onClose={() => setShowDueDateModal(false)}
            onSubmit={handleSetDueDate}
          />
        )}
        {showScanner && (
          <ScannerModal 
            onClose={() => setShowScanner(false)} 
            onScan={(data) => {
              setShowScanner(false);
              // Handle QR data: if it's a UPI link or ID, maybe auto-populate or find customer
              if (data.startsWith('upi://') || data.includes('@upi')) {
                // Try to find customer by UPI (not yet in schema, but for future)
                // For now, let's just show an alert or set it as a note if adding tx
                const params = new URLSearchParams(data.split('?')[1]);
                const amount = params.get('am');
                if (amount && selectedCustomer) {
                  setShowTxModal('TAKE');
                  // We'd need a way to pass this amount to the modal
                }
              }
              
              // If it's a phone number or ID, find customer
              const found = customers.find(c => c.phone === data || c.id === data);
              if (found) {
                setSelectedCustomer(found);
              }
            }} 
          />
        )}
        {showAddModal && (
          <AddCustomerModal 
            onClose={() => setShowAddModal(false)} 
            onAdd={(c) => {
              // Add to Firestore - filter out undefined photoUrl
              const customerData: any = {
                name: c.name,
                phone: c.phone,
                balance: 0,
                ownerId: user.uid,
                createdAt: serverTimestamp()
              };
              
              if (c.photoUrl) {
                customerData.photoUrl = c.photoUrl;
              }

              addDoc(collection(db, 'customers'), customerData)
                .then(() => setShowAddModal(false))
                .catch(err => handleFirestoreError(err, OperationType.CREATE, 'customers'));
            }}
          />
        )}
        {showEditModal && selectedCustomer && (
          <EditCustomerModal 
            customer={selectedCustomer}
            onClose={() => setShowEditModal(false)}
            onUpdate={handleUpdateCustomer}
          />
        )}
        {showTxModal && (
          <TransactionModal 
            type={showTxModal} 
            customerName={selectedCustomer?.name || ''}
            currentBalance={selectedCustomer?.balance || 0}
            onClose={() => setShowTxModal(null)}
            onSubmit={(amount, note) => addTransaction(showTxModal, amount, note)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

// --- Dashboard View ---

function DashboardView({ customers }: { customers: Customer[] }) {
  const stats = useMemo(() => {
    const totalDue = customers.reduce((sum, c) => sum + (c.balance > 0 ? c.balance : 0), 0);
    const totalAdvance = customers.reduce((sum, c) => sum + (c.balance < 0 ? Math.abs(c.balance) : 0), 0);
    const customerCount = customers.length;
    const dueCount = customers.filter(c => c.balance > 0).length;
    const advanceCount = customers.filter(c => c.balance < 0).length;
    
    // Top 5 debtors
    const topDebtors = [...customers]
      .filter(c => c.balance > 0)
      .sort((a, b) => b.balance - a.balance)
      .slice(0, 5)
      .map(c => ({ name: c.name, amount: c.balance }));

    const pieData = [
      { name: 'Due', value: dueCount, color: '#EF4444' },
      { name: 'Advance', value: advanceCount, color: '#22C55E' },
      { name: 'Zero', value: customerCount - dueCount - advanceCount, color: '#94A3B8' }
    ].filter(d => d.value > 0);

    return { totalDue, totalAdvance, customerCount, dueCount, advanceCount, topDebtors, pieData };
  }, [customers]);

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 pb-40">
      <div className="flex flex-col gap-1 mb-2">
        <h2 className="text-2xl font-black text-gray-900 leading-tight">Financial Insights</h2>
        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest leading-none">Shop performance summary</p>
      </div>
      {/* Key Metrics */}
      <div className="grid grid-cols-2 gap-4">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white p-5 rounded-[32px] border border-gray-100 shadow-sm"
          >
            <div className="w-10 h-10 rounded-2xl bg-red-50 flex items-center justify-center text-red-500 mb-4">
              <TrendingDown className="w-5 h-5" />
            </div>
            <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">TO RECEIVE</p>
            <h3 className="text-xl font-black text-red-500">₹{stats.totalDue.toLocaleString()}</h3>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white p-5 rounded-[32px] border border-gray-100 shadow-sm"
          >
            <div className="w-10 h-10 rounded-2xl bg-green-50 flex items-center justify-center text-green-500 mb-4">
              <TrendingUp className="w-5 h-5" />
            </div>
            <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">TO PAY</p>
            <h3 className="text-xl font-black text-green-600">₹{stats.totalAdvance.toLocaleString()}</h3>
          </motion.div>
        </div>

        {/* Secondary Stats */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white p-6 rounded-[32px] border border-gray-100 shadow-sm flex items-center justify-between"
        >
          <div>
            <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">TOTAL CUSTOMERS</p>
            <h3 className="text-2xl font-black text-gray-900">{stats.customerCount}</h3>
          </div>
          <div className="flex gap-2">
            <div className="text-right">
              <p className="text-[10px] font-bold text-red-500">DUE</p>
              <p className="font-bold text-gray-700">{stats.dueCount}</p>
            </div>
            <div className="w-px h-8 bg-gray-100 mx-1" />
            <div className="text-right">
              <p className="text-[10px] font-bold text-green-500">ADV</p>
              <p className="font-bold text-gray-700">{stats.advanceCount}</p>
            </div>
          </div>
        </motion.div>

        {/* Top Debtors Chart */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white p-6 rounded-[40px] border border-gray-100 shadow-sm"
        >
          <div className="flex items-center justify-between mb-6">
            <h4 className="font-black text-[12px] uppercase tracking-[0.2em] text-gray-400">Top Pending Dues</h4>
            <BarChart3 className="w-4 h-4 text-gray-300" />
          </div>
          
          <div className="h-64 w-full relative min-w-0">
            <ResponsiveContainer width="99%" height={256} debounce={50}>
              <BarChart data={stats.topDebtors} layout="vertical" margin={{ left: -20, right: 20 }}>
                <XAxis type="number" hide />
                <YAxis 
                  dataKey="name" 
                  type="category" 
                  axisLine={false} 
                  tickLine={false}
                  fontSize={12}
                  fontWeight={700}
                  width={80}
                />
                <Tooltip 
                  cursor={{ fill: 'transparent' }}
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      return (
                        <div className="bg-gray-900 text-white px-3 py-2 rounded-xl text-xs font-bold shadow-xl">
                          ₹{payload[0].value}
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Bar dataKey="amount" radius={[0, 12, 12, 0]} barSize={24}>
                  {stats.topDebtors.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={index === 0 ? '#2563EB' : '#60A5FA'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Customer Distribution */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-white p-6 rounded-[40px] border border-gray-100 shadow-sm"
        >
          <div className="flex items-center justify-between mb-6">
            <h4 className="font-black text-[12px] uppercase tracking-[0.2em] text-gray-400">Status Distribution</h4>
            <PieChartIcon className="w-4 h-4 text-gray-300" />
          </div>
          
          <div className="flex items-center gap-4">
            <div className="h-32 w-32 relative min-w-0">
              <ResponsiveContainer width="99%" height={128} debounce={50}>
                <PieChart>
                  <Pie
                    data={stats.pieData}
                    innerRadius={40}
                    outerRadius={60}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {stats.pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex-1 space-y-2">
              {stats.pieData.map((d, i) => (
                <div key={i} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full" style={{ backgroundColor: d.color }} />
                    <span className="text-xs font-bold text-gray-600">{d.name}</span>
                  </div>
                  <span className="text-xs font-black text-gray-900">{Math.round((d.value/stats.customerCount)*100)}%</span>
                </div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Tips / Insights */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-blue-600 p-8 rounded-[40px] text-white overflow-hidden relative"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16 blur-2xl" />
          <h4 className="font-black text-lg mb-2 relative z-10">Smart Insight</h4>
          <p className="text-sm font-medium text-blue-100 leading-relaxed relative z-10">
            {stats.dueCount > stats.customerCount / 2 
              ? "More than half of your customers have outstanding dues. Consider sending friendly reminders to improve collections."
              : "Great job! Most of your customer accounts are settled or in advance. Keep it up!"}
          </p>
        </motion.div>
      </div>
    );
  }

// --- Detail & Modal Sub-components ---

function CustomerDetail({ customer, transactions, onBack, onNext, onPrev, onAction, onEdit, onSummary, onSetDueDate, onSettle, onDelete, onDeleteTransaction, upiId, reminderTemplate, shopName, onScanOpen }: { 
  customer: Customer, 
  transactions: Transaction[],
  onBack: () => void, 
  onNext?: () => void,
  onPrev?: () => void,
  onAction: (type: TransactionType) => void,
  onEdit: () => void,
  onSummary: () => void,
  onSetDueDate: () => void,
  onSettle: () => void,
  onDelete: () => void,
  onDeleteTransaction: (id: string) => void,
  upiId?: string,
  reminderTemplate?: string,
  shopName?: string,
  onScanOpen: () => void
}) {
  const isDue = customer.balance > 0;
  const [txFilter, setTxFilter] = useState<'ALL' | 'GIVE' | 'TAKE'>('ALL');
  const [showingPayNow, setShowingPayNow] = useState(false);
  const [showMenu, setShowMenu] = useState(false);

  const filteredTransactions = useMemo(() => {
    if (txFilter === 'ALL') return transactions;
    return transactions.filter(tx => tx.type === txFilter);
  }, [transactions, txFilter]);

  const handleSendReminder = (type: 'SMS' | 'DUE' | 'PAY' | 'LINK' = 'SMS') => {
    let msg = '';
    const name = customer.name;
    const balance = Math.abs(customer.balance).toString();
    const shop = shopName || auth.currentUser?.displayName || 'our shop';

    if (type === 'DUE' && customer.dueDate) {
      msg = `Namaskara ${name}, just a reminders that your outstanding balance of ₹${balance} is due on ${ensureDate(customer.dueDate).toLocaleDateString()}. Please settle it when possible. Dhanyavadagalu!`;
    } else if ((type === 'PAY' || type === 'LINK') && upiId) {
      const upiLink = `upi://pay?pa=${upiId}&pn=${encodeURIComponent(shop)}&am=${balance}&cu=INR`;
      msg = `Namaskara ${name}, you can pay your outstanding balance of ₹${balance} using this UPI link: ${upiLink}. Dhanyavadagalu!`;
    } else {
      if (reminderTemplate) {
        msg = reminderTemplate
          .replace('{name}', name)
          .replace('{balance}', balance)
          .replace('{shop}', shop);
      } else {
        msg = `Namaskara ${name},\n\nThis is a friendly reminder from Grama-Khata. Your outstanding balance is ₹${balance}. Please settle the payment at your earliest convenience.\n\nDhanyavadagalu!`;
      }
    }
    const url = `https://wa.me/${customer.phone.replace(/\D/g, '')}?text=${encodeURIComponent(msg)}`;
    window.open(url, '_blank');
  };
  
  return (
    <motion.div 
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 20 }}
      className="flex-1 flex flex-col bg-white"
    >
      <div className="p-4 flex items-center gap-4">
        <div className="flex items-center gap-1">
          <button onClick={onBack} className="p-2 -ml-2 text-gray-400 hover:text-gray-900 transition-colors" title="Back to List">
            <ArrowLeft className="w-6 h-6" />
          </button>
          
          <div className="flex items-center bg-gray-50 rounded-xl p-1 border border-gray-100">
            <button 
              onClick={onPrev} 
              disabled={!onPrev}
              className={`p-1.5 rounded-lg transition-all ${onPrev ? 'text-gray-600 hover:bg-white hover:shadow-sm' : 'text-gray-200 cursor-not-allowed'}`}
              title="Previous Customer"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <div className="h-4 w-[1px] bg-gray-200 mx-1" />
            <button 
              onClick={onNext} 
              disabled={!onNext}
              className={`p-1.5 rounded-lg transition-all ${onNext ? 'text-gray-600 hover:bg-white hover:shadow-sm' : 'text-gray-200 cursor-not-allowed'}`}
              title="Next Customer"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="flex-1 flex items-center gap-3 overflow-hidden">
          <div className="w-10 h-10 rounded-full bg-gray-100 overflow-hidden">
            {customer.photoUrl ? <img src={customer.photoUrl} alt={customer.name} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center font-bold text-gray-400">{customer.name.charAt(0)}</div>}
          </div>
          <div>
            <h3 className="font-bold text-gray-900">{customer.name}</h3>
            <p className="text-xs text-gray-500">{customer.phone}</p>
          </div>
        </div>
        <div className="flex gap-2 relative">
          <button onClick={() => setShowMenu(!showMenu)} className="p-2 text-gray-600 bg-gray-50 rounded-xl">
            <MoreVertical className="w-5 h-5" />
          </button>
          
          <AnimatePresence>
            {showMenu && (
              <motion.div 
                initial={{ opacity: 0, y: 10, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 10, scale: 0.95 }}
                className="absolute right-0 top-12 w-56 bg-white rounded-2xl shadow-2xl border border-gray-100 z-50 overflow-hidden"
              >
                <div className="p-2 space-y-1">
                  <button 
                    onClick={() => { onSummary(); setShowMenu(false); }}
                    className="w-full flex items-center gap-3 p-3 text-sm font-bold text-gray-700 hover:bg-blue-50 rounded-xl transition-colors"
                  >
                    <History className="w-4 h-4 text-blue-500" />
                    Transaction Summary
                  </button>
                  <button 
                    onClick={() => { onEdit(); setShowMenu(false); }}
                    className="w-full flex items-center gap-3 p-3 text-sm font-bold text-gray-700 hover:bg-gray-50 rounded-xl transition-colors"
                  >
                    <Edit2 className="w-4 h-4 text-gray-500" />
                    Edit Khata Details
                  </button>
                  <button 
                    onClick={() => { onScanOpen(); setShowMenu(false); }}
                    className="w-full flex items-center gap-3 p-3 text-sm font-bold text-gray-700 hover:bg-indigo-50 rounded-xl transition-colors"
                  >
                    <QrCode className="w-4 h-4 text-indigo-500" />
                    Scan Payment Proof
                  </button>
                  <div className="h-[1px] bg-gray-100 my-1 mx-2" />
                  <button 
                    onClick={() => { onDelete(); setShowMenu(false); }}
                    className="w-full flex items-center gap-3 p-3 text-sm font-bold text-red-600 hover:bg-red-50 rounded-xl transition-colors"
                  >
                    <Trash2 className="w-4 h-4 text-red-500" />
                    Delete Customer
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <a href={`tel:${customer.phone}`} className="p-2 text-blue-600 bg-blue-50 rounded-xl">
            <Phone className="w-5 h-5" />
          </a>
          <button onClick={() => handleSendReminder()} className="p-2 text-green-600 bg-green-50 rounded-xl">
            <MessageCircle className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className={`mx-4 p-8 rounded-[32px] text-center mb-4 ${isDue ? 'bg-red-500 text-white' : 'bg-green-500 text-white shadow-xl shadow-green-100'}`}>
        <p className="text-sm font-bold opacity-80 uppercase tracking-widest mb-1">
          {isDue ? 'CUSTOMER SHOULD GIVE' : 'YOU SHOULD GIVE'}
        </p>
        <h2 className="text-5xl font-black">₹{Math.abs(customer.balance)}</h2>
      </div>

      {isDue && (
        <div className="px-4 mb-6 space-y-4">
          <button 
            onClick={onSettle}
            className="w-full flex items-center justify-center gap-3 bg-green-600 text-white py-5 rounded-[24px] font-black text-lg shadow-xl shadow-green-100 active:scale-95 transition-all border-4 border-green-50"
          >
            <CheckCircle2 className="w-6 h-6" />
            Mark as Paid (₹{customer.balance})
          </button>

          <div className="flex gap-3">
            <button 
              onClick={() => handleSendReminder()}
              className="flex-1 flex items-center justify-center gap-2 bg-blue-50 text-blue-600 py-4 rounded-2xl font-bold border border-blue-100 active:scale-95 transition-all"
            >
              <Bell className="w-4 h-4" />
              Remind
            </button>
            {upiId ? (
              <div className="flex-1 flex gap-2">
                <button 
                  onClick={() => handleSendReminder('PAY')}
                  className="flex-1 flex items-center justify-center gap-2 bg-indigo-600 text-white py-4 rounded-2xl font-bold border-4 border-indigo-50 active:scale-95 transition-all shadow-lg shadow-indigo-100"
                >
                  <Share2 className="w-4 h-4" />
                  Pay Now
                </button>
                <button 
                  onClick={() => setShowingPayNow(true)}
                  className="flex-1 flex items-center justify-center gap-2 bg-gray-900 text-white py-4 rounded-2xl font-bold border-4 border-gray-800 active:scale-95 transition-all shadow-lg shadow-gray-200"
                >
                  <QrCode className="w-4 h-4" />
                  QR
                </button>
              </div>
            ) : (
              <button 
                disabled
                className="flex-1 flex items-center justify-center gap-2 bg-gray-100 text-gray-400 py-4 rounded-2xl font-bold border-4 border-gray-50 opacity-50"
              >
                Set UPI
              </button>
            )}
          </div>
          {!customer.dueDate && (
            <button 
              onClick={onSetDueDate}
              className="w-full flex items-center justify-center gap-2 bg-white text-blue-600 py-4 rounded-2xl font-bold border-4 border-blue-50 active:scale-95 transition-all shadow-sm"
            >
              <Calendar className="w-4 h-4" />
              Set Payment Due Date
            </button>
          )}
          {customer.dueDate && (
            <button 
              onClick={() => handleSendReminder('DUE')}
              className="w-full flex items-center justify-center gap-2 bg-green-600 text-white py-4 rounded-2xl font-bold border-4 border-green-50 active:scale-95 transition-all shadow-lg shadow-green-100"
            >
              <History className="w-4 h-4" />
              Due Alert
            </button>
          )}
        </div>
      )}

      <AnimatePresence>
        {showingPayNow && upiId && (
          <PaymentQrModal 
            upiId={upiId} 
            amount={Math.abs(customer.balance)} 
            customerName={customer.name}
            onClose={() => setShowingPayNow(false)} 
          />
        )}
      </AnimatePresence>

      <div className="flex-1 overflow-y-auto px-4">
        <div className="bg-gray-50 rounded-[24px] p-4 mb-6 border border-gray-100">
          <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-3">Customer Information</h4>
          <div className="space-y-3">
            <div className="flex justify-between items-center text-sm">
              <span className="text-gray-500">Member Since</span>
              <span className="font-semibold">{customer.createdAt ? ensureDate(customer.createdAt).toLocaleDateString() : 'N/A'}</span>
            </div>
            <div className="flex justify-between items-center text-sm">
              <span className="text-gray-500">Phone Verified</span>
              <span className="flex items-center gap-1 font-semibold text-green-600">
                <CheckCircle2 className="w-4 h-4" /> Yes
              </span>
            </div>
            {customer.address && (
              <div className="flex justify-between items-start text-sm">
                <span className="text-gray-500 min-w-[80px]">Address</span>
                <span className="font-semibold text-right">{customer.address}</span>
              </div>
            )}
            {customer.notes && (
              <div className="flex flex-col gap-1 text-sm bg-blue-50/50 p-2 rounded-lg border border-blue-100/50">
                <span className="text-[10px] font-bold text-blue-400 uppercase">Notes</span>
                <span className="text-gray-700">{customer.notes}</span>
              </div>
            )}
            {isDue && (
              <div className="flex justify-between items-center text-sm mt-3 pt-3 border-t border-gray-100">
                <div className="flex items-center gap-2 text-gray-500">
                  <Clock className="w-4 h-4" />
                  <span>Due Date</span>
                </div>
                {customer.dueDate ? (
                  <div className="flex items-center gap-2">
                    <span className={`font-bold ${ensureDate(customer.dueDate) < new Date() ? 'text-red-500' : 'text-blue-600'}`}>
                      {ensureDate(customer.dueDate).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}
                    </span>
                    <button onClick={onSetDueDate} className="text-[10px] bg-gray-100 px-2 py-1 rounded-md font-bold text-gray-500">CHANGE</button>
                  </div>
                ) : (
                  <button onClick={onSetDueDate} className="text-blue-600 font-bold">Set Due Date</button>
                )}
              </div>
            )}
          </div>
        </div>

        <div className="flex items-center justify-between mb-4">
          <h4 className="font-bold text-gray-400 text-xs uppercase tracking-widest flex items-center gap-2">
            <Calendar className="w-4 h-4" /> RECENT TRANSACTIONS
          </h4>
          <div className="flex gap-1 bg-gray-100 p-1 rounded-xl">
            {['ALL', 'GIVE', 'TAKE'].map(filter => (
              <button
                key={filter}
                onClick={() => setTxFilter(filter as any)}
                className={`px-3 py-1 text-[10px] font-bold rounded-lg transition-all ${txFilter === filter ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-400'}`}
              >
                {filter}
              </button>
            ))}
          </div>
        </div>
        <div className="space-y-0">
          {filteredTransactions.map(tx => (
            <TransactionItem 
              key={tx.id} 
              tx={tx} 
              onDelete={onDeleteTransaction}
            />
          ))}
          {filteredTransactions.length === 0 && (
            <div className="text-center py-12 text-gray-400">
              {txFilter === 'ALL' ? 'No transactions yet' : `No ${txFilter} transactions`}
            </div>
          )}
        </div>
      </div>

      <div className="p-4 grid grid-cols-2 gap-4 bg-white border-t border-gray-100 sticky bottom-0">
        <button 
          onClick={() => onAction('GIVE')}
          className="koduvudu w-full py-4 rounded-2xl font-bold flex flex-col items-center justify-center gap-1 shadow-lg shadow-red-200 bg-red-500 text-white active:scale-95 transition-all"
        >
          <span className="text-xs opacity-80">Koduvudu</span>
          <div className="flex items-center gap-2">
            <ArrowUpRight className="w-5 h-5" />
            <span>GIVE ₹</span>
          </div>
        </button>
        <button 
          onClick={() => onAction('TAKE')}
          className="tegedukolluvudu w-full py-4 rounded-2xl font-bold flex flex-col items-center justify-center gap-1 shadow-lg shadow-green-200 bg-green-600 text-white active:scale-95 transition-all"
        >
          <span className="text-xs opacity-80">Tegedukolluvudu</span>
          <div className="flex items-center gap-2">
            <ArrowDownLeft className="w-5 h-5" />
            <span>TAKE ₹</span>
          </div>
        </button>
      </div>
    </motion.div>
  );
}

function AddCustomerModal({ onClose, onAdd }: { onClose: () => void, onAdd: (c: { name: string, phone: string, address?: string, notes?: string, photoUrl?: string }) => void }) {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');
  const [photo, setPhoto] = useState<string | null>(null);
  const [takingPhoto, setTakingPhoto] = useState(false);

  const handleTakePhoto = () => {
    // In a real app, use navigator.mediaDevices.getUserMedia
    // For demo, we'll just use a placeholder or prompt for upload
    setTakingPhoto(true);
    // Simulating photo capture
    setTimeout(() => {
      setPhoto(`https://api.dicebear.com/7.x/initials/svg?seed=${name || 'C'}`);
      setTakingPhoto(false);
    }, 1000);
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-4"
    >
      <motion.div 
        initial={{ y: "100%" }}
        animate={{ y: 0 }}
        exit={{ y: "100%" }}
        className="bg-white w-full max-w-md rounded-t-[32px] sm:rounded-[32px] p-6 shadow-2xl"
      >
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold">New Customer</h2>
          <button onClick={onClose} className="p-2 bg-gray-100 rounded-full"><X className="w-5 h-5" /></button>
        </div>

        <div className="space-y-6">
          <div className="flex flex-col items-center">
            <div className="w-24 h-24 bg-gray-100 rounded-3xl mb-3 flex items-center justify-center overflow-hidden border-2 border-gray-100">
              {photo ? (
                <img src={photo} className="w-full h-full object-cover" alt="Preview" />
              ) : (
                <Camera className="w-10 h-10 text-gray-300" />
              )}
            </div>
            <button 
              onClick={handleTakePhoto}
              className="text-blue-600 font-bold text-sm flex items-center gap-2"
            >
              {takingPhoto ? 'Capturing...' : (photo ? 'Retake Photo' : 'Add Photo Identification')}
            </button>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-1 ml-1">NAME</label>
              <input 
                type="text" 
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Enter customer name"
                className="w-full bg-gray-50 border-0 rounded-2xl py-4 px-4 focus:ring-2 focus:ring-blue-100"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-1 ml-1">PHONE NUMBER</label>
              <input 
                type="tel" 
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="Mobile number"
                className="w-full bg-gray-50 border-0 rounded-2xl py-4 px-4 focus:ring-2 focus:ring-blue-100"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-1 ml-1">ADDRESS (OPTIONAL)</label>
              <input 
                type="text" 
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="Village or ward name"
                className="w-full bg-gray-50 border-0 rounded-2xl py-4 px-4 focus:ring-2 focus:ring-blue-100"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-1 ml-1">NOTES (OPTIONAL)</label>
              <textarea 
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Anything to remember..."
                className="w-full bg-gray-50 border-0 rounded-2xl py-4 px-4 focus:ring-2 focus:ring-blue-100 resize-none"
                rows={2}
              />
            </div>
          </div>

          <button 
            disabled={!name || !phone}
            onClick={() => onAdd({ name, phone, address, notes, photoUrl: photo || undefined })}
            className="w-full bg-blue-600 text-white py-4 rounded-2xl font-bold shadow-lg shadow-blue-100 disabled:opacity-50 disabled:shadow-none transition-all active:scale-95"
          >
            Create Khata
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

function EditCustomerModal({ customer, onClose, onUpdate }: { customer: Customer, onClose: () => void, onUpdate: (c: { name: string, phone: string, address?: string, notes?: string, photoUrl?: string }) => void }) {
  const [name, setName] = useState(customer.name);
  const [phone, setPhone] = useState(customer.phone);
  const [address, setAddress] = useState(customer.address || '');
  const [notes, setNotes] = useState(customer.notes || '');
  const [photo, setPhoto] = useState<string | null>(customer.photoUrl || null);
  const [takingPhoto, setTakingPhoto] = useState(false);

  const handleTakePhoto = () => {
    setTakingPhoto(true);
    setTimeout(() => {
      setPhoto(`https://api.dicebear.com/7.x/initials/svg?seed=${name || 'C'}`);
      setTakingPhoto(false);
    }, 1000);
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-4"
    >
      <motion.div 
        initial={{ y: "100%" }}
        animate={{ y: 0 }}
        exit={{ y: "100%" }}
        className="bg-white w-full max-w-md rounded-t-[32px] sm:rounded-[32px] p-6 shadow-2xl max-h-[90vh] overflow-y-auto"
      >
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold">Edit Customer</h2>
          <button onClick={onClose} className="p-2 bg-gray-100 rounded-full"><X className="w-5 h-5" /></button>
        </div>

        <div className="space-y-6">
          <div className="flex flex-col items-center">
            <div className="w-24 h-24 bg-gray-100 rounded-3xl mb-3 flex items-center justify-center overflow-hidden border-2 border-gray-100">
              {photo ? (
                <img src={photo} className="w-full h-full object-cover" alt="Preview" />
              ) : (
                <Camera className="w-10 h-10 text-gray-300" />
              )}
            </div>
            <button 
              onClick={handleTakePhoto}
              className="text-blue-600 font-bold text-sm flex items-center gap-2"
            >
              {takingPhoto ? 'Capturing...' : (photo ? 'Retake Photo' : 'Add Photo')}
            </button>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-1 ml-1">NAME</label>
              <input 
                type="text" 
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Enter customer name"
                className="w-full bg-gray-50 border-0 rounded-2xl py-4 px-4 focus:ring-2 focus:ring-blue-100 transition-all font-medium"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-1 ml-1">PHONE NUMBER</label>
              <input 
                type="tel" 
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="Mobile number"
                className="w-full bg-gray-50 border-0 rounded-2xl py-4 px-4 focus:ring-2 focus:ring-blue-100 transition-all font-medium"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-1 ml-1">ADDRESS</label>
              <input 
                type="text" 
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="Village/Area"
                className="w-full bg-gray-50 border-0 rounded-2xl py-4 px-4 focus:ring-2 focus:ring-blue-100 transition-all font-medium"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-1 ml-1">NOTES</label>
              <textarea 
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Customer notes..."
                className="w-full bg-gray-50 border-0 rounded-2xl py-4 px-4 focus:ring-2 focus:ring-blue-100 resize-none transition-all font-medium"
                rows={2}
              />
            </div>
          </div>

          <button 
            disabled={!name || !phone}
            onClick={() => onUpdate({ name, phone, address, notes, photoUrl: photo || undefined })}
            className="w-full bg-blue-600 text-white py-4 rounded-2xl font-bold shadow-lg shadow-blue-100 transition-all active:scale-95"
          >
            Update Khata
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

function SetDueDateModal({ onClose, onSubmit }: { onClose: () => void, onSubmit: (date: Date) => void }) {
  const [date, setDate] = useState('');

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-4"
    >
      <motion.div 
        initial={{ y: "100%" }}
        animate={{ y: 0 }}
        exit={{ y: "100%" }}
        className="bg-white w-full max-w-md rounded-t-[32px] sm:rounded-[32px] p-6 shadow-2xl"
      >
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold">Set Due Date</h2>
          <button onClick={onClose} className="p-2 bg-gray-100 rounded-full"><X className="w-5 h-5" /></button>
        </div>

        <div className="space-y-6">
          <div>
            <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-1 ml-1">SELECT DATE</label>
            <input 
              type="date" 
              value={date}
              onChange={(e) => setDate(e.target.value)}
              min={new Date().toISOString().split('T')[0]}
              className="w-full bg-gray-50 border-0 rounded-2xl py-4 px-4 focus:ring-2 focus:ring-blue-100 font-bold"
            />
          </div>

          <button 
            disabled={!date}
            onClick={() => onSubmit(new Date(date))}
            className="w-full bg-blue-600 text-white py-4 rounded-2xl font-bold shadow-lg shadow-blue-100 active:scale-95 transition-all"
          >
            Confirm Due Date
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

function PaymentQrModal({ upiId, amount, customerName, onClose }: { upiId: string, amount: number, customerName: string, onClose: () => void }) {
  const upiLink = amount > 0 
    ? `upi://pay?pa=${upiId}&pn=${encodeURIComponent(auth.currentUser?.displayName || 'Vendor')}&am=${amount}&cu=INR`
    : `upi://pay?pa=${upiId}&pn=${encodeURIComponent(auth.currentUser?.displayName || 'Vendor')}&cu=INR`;

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-6"
      onClick={onClose}
    >
      <motion.div 
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: 20 }}
        className="bg-white w-full max-w-xs rounded-[40px] p-8 text-center shadow-2xl relative"
        onClick={e => e.stopPropagation()}
      >
        <button onClick={onClose} className="absolute top-6 right-6 p-2 bg-gray-100 rounded-full hover:bg-gray-200 transition-colors">
          <X className="w-5 h-5 text-gray-500" />
        </button>
        
        <h3 className="text-xl font-black mb-1 text-gray-900 mt-2">Scan to Pay</h3>
        <p className="text-[10px] text-gray-400 mb-6 font-bold uppercase tracking-widest leading-none">
          {amount > 0 ? `Payable Amount: ₹${amount}` : 'Merchant Payment'}
        </p>
        
        <div className="aspect-square bg-white rounded-3xl p-6 mb-6 border-4 border-gray-50 flex items-center justify-center shadow-inner">
          <QRCodeSVG 
            value={upiLink} 
            size={200}
            level="H"
            includeMargin={false}
            imageSettings={{
              src: "https://ais-dev-k6q6rxmi32d4k6nhnd5jqn-696007905074.asia-southeast1.run.app/favicon.ico", // Fallback, normally you'd use a local svg or GK logo
              x: undefined,
              y: undefined,
              height: 24,
              width: 24,
              excavate: true,
            }}
          />
        </div>
        
        <div className="space-y-3 bg-gray-50 p-4 rounded-2xl border border-gray-100">
          <div className="flex justify-between items-center text-[10px]">
             <span className="font-bold text-gray-400 uppercase tracking-widest">Merchant</span>
             <span className="font-black text-gray-900">{auth.currentUser?.displayName || 'Grama Vendor'}</span>
          </div>
          <div className="flex justify-between items-center text-[10px]">
             <span className="font-bold text-gray-400 uppercase tracking-widest">UPI ID</span>
             <span className="font-black text-blue-600">{upiId}</span>
          </div>
        </div>

        <button 
          onClick={onClose}
          className="w-full mt-6 bg-gray-900 text-white py-4 rounded-2xl font-black active:scale-95 transition-all text-sm uppercase tracking-widest shadow-xl shadow-gray-200"
        >
          Close QR
        </button>
      </motion.div>
    </motion.div>
  );
}

function TransactionSummaryModal({ transactions, customerName, onClose }: { transactions: Transaction[], customerName: string, onClose: () => void }) {
  const summary = useMemo(() => {
    const totalGive = transactions.filter(t => t.type === 'GIVE').reduce((s, t) => s + t.amount, 0);
    const totalTake = transactions.filter(t => t.type === 'TAKE').reduce((s, t) => s + t.amount, 0);
    return { totalGive, totalTake, count: transactions.length };
  }, [transactions]);

  const handleShareStatement = () => {
    const balance = summary.totalGive - summary.totalTake;
    const text = `*Billing Summary for ${customerName}*\n\n` +
      `📅 Date: ${new Date().toLocaleDateString()}\n` +
      `--------------------------\n` +
      `🔴 Total Borrowed: ₹${summary.totalGive}\n` +
      `🟢 Total Paid: ₹${summary.totalTake}\n` +
      `--------------------------\n` +
      `💰 *Net Balance: ₹${Math.abs(balance)} (${balance >= 0 ? 'To Pay' : 'Advanced'})*\n\n` +
      `Total Transactions: ${summary.count}\n\n` +
      `Generated via Grama-Khata Digital`;

    if (navigator.share && /Android|iPhone|iPad/i.test(navigator.userAgent)) {
      navigator.share({ text }).catch(console.error);
    } else {
      navigator.clipboard.writeText(text).then(() => {
        // Notification instead of alert
        console.log('Summary copied to clipboard!');
      });
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-4"
    >
      <motion.div 
        initial={{ y: "100%" }}
        animate={{ y: 0 }}
        exit={{ y: "100%" }}
        className="bg-white w-full max-w-md rounded-t-[32px] sm:rounded-[32px] p-6 shadow-2xl"
      >
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl font-bold">Billing Summary</h2>
            <p className="text-gray-500">For {customerName}</p>
          </div>
          <button onClick={onClose} className="p-2 bg-gray-100 rounded-full"><X className="w-5 h-5" /></button>
        </div>

        <div className="space-y-4">
          <div className="flex items-center gap-4 bg-red-50 p-6 rounded-3xl border border-red-100">
            <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center text-red-600">
              <TrendingUp className="w-6 h-6" />
            </div>
            <div>
              <p className="text-[10px] font-bold text-red-400 uppercase tracking-widest">Total Borrowed (Koduvudu)</p>
              <h3 className="text-2xl font-black text-red-600">₹{summary.totalGive}</h3>
            </div>
          </div>

          <div className="flex items-center gap-4 bg-green-50 p-6 rounded-3xl border border-green-100">
            <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center text-green-600">
              <TrendingDown className="w-6 h-6" />
            </div>
            <div>
              <p className="text-[10px] font-bold text-green-400 uppercase tracking-widest">Total Paid (Tegedukolluvudu)</p>
              <h3 className="text-2xl font-black text-green-600">₹{summary.totalTake}</h3>
            </div>
          </div>

          <div className="bg-gray-50 p-6 rounded-3xl flex justify-between items-center">
            <span className="font-bold text-gray-500">Net Position</span>
            <span className={`text-xl font-black ${summary.totalGive > summary.totalTake ? 'text-red-600' : 'text-green-600'}`}>
              ₹{Math.abs(summary.totalGive - summary.totalTake)}
            </span>
          </div>

          <p className="text-center text-xs text-gray-400 py-2">Based on {summary.count} transactions</p>

          <div className="flex gap-2">
            <button 
              onClick={handleShareStatement}
              className="flex-1 bg-blue-600 text-white py-4 rounded-2xl font-bold active:scale-95 transition-all flex items-center justify-center gap-2"
            >
              <Share2 className="w-4 h-4" />
              Share Statement
            </button>
            <button 
              onClick={onClose}
              className="flex-1 bg-gray-900 text-white py-4 rounded-2xl font-bold active:scale-95 transition-all"
            >
              Close
            </button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

function ScannerModal({ onClose, onScan }: { onClose: () => void, onScan: (data: string) => void }) {
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const html5QrCode = new Html5Qrcode("reader");
    const config = { fps: 10, qrbox: { width: 250, height: 250 } };

    html5QrCode.start(
      { facingMode: "environment" },
      config,
      (decodedText) => {
        onScan(decodedText);
        html5QrCode.stop().catch(err => console.error(err));
      },
      () => {
        // No QR found in this frame
      }
    ).catch((err) => {
      console.error(err);
      if (err.toString().includes("NotAllowedError") || err.toString().includes("Permission denied")) {
        setError("Camera permission was denied. Please allow camera access in your browser settings to use the scanner.");
      } else {
        setError("Could not start camera. Please ensure no other app is using it.");
      }
    });

    return () => {
      if (html5QrCode.isScanning) {
        html5QrCode.stop().catch(err => console.error(err));
      }
    };
  }, []);

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-black flex flex-col items-center justify-center p-6"
    >
      <div className="w-full max-w-sm flex flex-col gap-6">
        <div className="flex items-center justify-between text-white">
          <h2 className="text-xl font-bold">Scan QR</h2>
          <button onClick={onClose} className="p-2 bg-white/10 rounded-full hover:bg-white/20 transition-colors"><X className="w-6 h-6" /></button>
        </div>
        
        <div className="aspect-square bg-white/5 rounded-3xl overflow-hidden border-2 border-white/20 relative flex items-center justify-center">
          {error ? (
            <div className="p-8 text-center space-y-4">
              <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mx-auto text-red-500">
                <Camera className="w-8 h-8" />
              </div>
              <p className="text-sm text-red-400 font-medium">{error}</p>
              <button 
                onClick={() => window.location.reload()}
                className="text-xs text-blue-400 font-bold uppercase tracking-widest border border-blue-400/30 px-4 py-2 rounded-full"
              >
                Try Refreshing
              </button>
            </div>
          ) : (
            <>
              <div id="reader" className="w-full h-full"></div>
              <div className="absolute inset-0 pointer-events-none border-4 border-dashed border-blue-500/50 m-12 rounded-2xl"></div>
            </>
          )}
        </div>

        {!error && (
          <p className="text-white/60 text-center text-sm">
            Scan customer's Khata card or payment UPI QR to quickly identify them.
          </p>
        )}

        <button 
          onClick={onClose}
          className="w-full bg-white text-black py-4 rounded-2xl font-bold active:scale-95 transition-all shadow-xl"
        >
          {error ? 'Close' : 'Cancel'}
        </button>
      </div>
    </motion.div>
  );
}

function TransactionModal({ type, customerName, currentBalance, onClose, onSubmit }: { 
  type: TransactionType, 
  customerName: string,
  currentBalance: number,
  onClose: () => void, 
  onSubmit: (amount: number, note: string) => void 
}) {
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-4"
    >
      <motion.div 
        initial={{ y: "100%" }}
        animate={{ y: 0 }}
        exit={{ y: "100%" }}
        className="bg-white w-full max-w-md rounded-t-[32px] sm:rounded-[32px] p-6 shadow-2xl"
      >
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl font-bold">{type === 'GIVE' ? 'Credit' : 'Payment'}</h2>
            <p className="text-gray-500">For {customerName}</p>
          </div>
          <button onClick={onClose} className="p-2 bg-gray-100 rounded-full"><X className="w-5 h-5" /></button>
        </div>

        <div className="space-y-6">
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-2xl font-bold text-gray-400">₹</span>
            <input 
              autoFocus
              type="number" 
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0.00"
              className="w-full bg-gray-50 border-0 rounded-2xl py-6 pl-10 pr-4 text-3xl font-black focus:ring-2 focus:ring-blue-100 text-gray-900"
            />
            {amount && parseFloat(amount) > 0 && (
              <div className="absolute -bottom-6 left-1 flex items-center gap-1">
                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">New Balance:</span>
                <span className={`text-[10px] font-black ${
                  (type === 'GIVE' ? currentBalance + parseFloat(amount) : currentBalance - parseFloat(amount)) > 0 
                  ? 'text-red-500' : 'text-green-600'
                }`}>
                  ₹{Math.abs(type === 'GIVE' ? currentBalance + parseFloat(amount) : currentBalance - parseFloat(amount))}
                </span>
                <ArrowRight className="w-2 h-2 text-gray-300" />
              </div>
            )}
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-1 ml-1 text-left">ITEM NOTE (OPTIONAL)</label>
            <input 
              type="text" 
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="e.g. Rice, Oil, Milk"
              className="w-full bg-gray-50 border-0 rounded-2xl py-4 px-4 focus:ring-2 focus:ring-blue-100"
            />
          </div>

          <button 
            disabled={!amount || parseFloat(amount) <= 0}
            onClick={() => onSubmit(parseFloat(amount), note)}
            className={`w-full py-5 rounded-2xl font-bold text-xl shadow-lg transition-all active:scale-95 text-white ${type === 'GIVE' ? 'bg-red-500 shadow-red-100' : 'bg-green-500 shadow-green-100'}`}
          >
            {type === 'GIVE' ? 'Give' : 'Take'} ₹{amount || '0'}
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}
