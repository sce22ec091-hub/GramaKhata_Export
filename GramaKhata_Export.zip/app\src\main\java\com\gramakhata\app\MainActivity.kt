package com.gramakhata.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import com.gramakhata.app.data.AppDatabase
import com.gramakhata.app.repository.LedgerRepository
import com.gramakhata.app.ui.CustomerDetailScreen
import com.gramakhata.app.ui.DashboardScreen
import com.gramakhata.app.viewmodel.CustomerDetailViewModel
import com.gramakhata.app.viewmodel.DashboardViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize dependencies
        val database = AppDatabase.getDatabase(this)
        val repository = LedgerRepository(database.customerDao(), database.transactionDao())

        setContent {
            var currentScreen by remember { mutableStateOf<Screen>(Screen.Dashboard) }

            when (val screen = currentScreen) {
                is Screen.Dashboard -> {
                    val viewModel = remember { DashboardViewModel(repository) }
                    DashboardScreen(
                        viewModel = viewModel,
                        onCustomerClick = { id -> currentScreen = Screen.CustomerDetail(id) },
                        onAddCustomerClick = { /* Handle Add */ }
                    )
                }
                is Screen.CustomerDetail -> {
                    val viewModel = remember(screen.id) { 
                        CustomerDetailViewModel(repository, screen.id) 
                    }
                    CustomerDetailScreen(
                        viewModel = viewModel,
                        onBack = { currentScreen = Screen.Dashboard }
                    )
                }
            }
        }
    }
}

sealed class Screen {
    object Dashboard : Screen()
    data class CustomerDetail(val id: Int) : Screen()
}
