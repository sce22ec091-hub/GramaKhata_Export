// ══ STATE ══
let state = {
  shopName: 'Raju Kirana Store',
  customers: [],
  transactions: [],
  currentCustomerId: null,
  txType: null, // 'give' | 'take'
  pin: '1234'
};

// ══ PERSISTENCE ══
function save() {
  localStorage.setItem('gk_customers', JSON.stringify(state.customers));
  localStorage.setItem('gk_transactions', JSON.stringify(state.transactions));
  localStorage.setItem('gk_shop', state.shopName);
  localStorage.setItem('gk_pin', state.pin);
}

function load() {
  state.customers = JSON.parse(localStorage.getItem('gk_customers') || '[]');
  state.transactions = JSON.parse(localStorage.getItem('gk_transactions') || '[]');
  state.shopName = localStorage.getItem('gk_shop') || 'Grama-Khata';
  state.pin = localStorage.getItem('gk_pin') || '1234';
  seedDemoData();
}

function seedDemoData() {
  if (state.customers.length > 0) return;
  const now = Date.now();
  state.customers = [
    { id: 1, name: 'Ramesh Kumar', phone: '9876543210', village: 'Chandapur', createdAt: now - 86400000 * 30 },
    { id: 2, name: 'Sunita Devi', phone: '9123456780', village: 'Mirjapur', createdAt: now - 86400000 * 20 },
    { id: 3, name: 'Mohan Lal', phone: '9988776655', village: 'Durgapur', createdAt: now - 86400000 * 10 },
    { id: 4, name: 'Geeta Bai', phone: '9871234560', village: 'Chandapur', createdAt: now - 86400000 * 5 }
  ];
  const txData = [
    { customerId: 1, amount: 850, type: 'give', note: 'Rice 5kg, Sugar 2kg', ts: now - 86400000 * 15 },
    { customerId: 1, amount: 200, type: 'take', note: 'Partial payment', ts: now - 86400000 * 10 },
    { customerId: 1, amount: 450, type: 'give', note: 'Oil 2L, Dal 1kg', ts: now - 86400000 * 5 },
    { customerId: 2, amount: 1200, type: 'give', note: 'Monthly ration', ts: now - 86400000 * 18 },
    { customerId: 2, amount: 1200, type: 'take', note: 'Full payment', ts: now - 86400000 * 3 },
    { customerId: 3, amount: 3500, type: 'give', note: 'Festival purchases', ts: now - 86400000 * 7 },
    { customerId: 3, amount: 500, type: 'take', note: 'Cash', ts: now - 86400000 * 2 },
    { customerId: 4, amount: 650, type: 'give', note: 'Soap, Shampoo, Biscuits', ts: now - 86400000 * 4 }
  ];
  let txId = 1;
  state.transactions = txData.map(t => ({ ...t, id: txId++ }));
  save();
}

// ══ HELPERS ══
function uid() { return Date.now() + Math.random().toString(36).slice(2); }

function getBalance(customerId) {
  return state.transactions
    .filter(t => t.customerId === customerId)
    .reduce((sum, t) => t.type === 'give' ? sum + t.amount : sum - t.amount, 0);
}

function getLastTxDate(customerId) {
  const txs = state.transactions.filter(t => t.customerId === customerId);
  if (!txs.length) return null;
  return Math.max(...txs.map(t => t.ts));
}

function daysSince(ts) {
  if (!ts) return 999;
  return Math.floor((Date.now() - ts) / 86400000);
}

function formatDate(ts) {
  if (!ts) return 'No entries';
  const d = new Date(ts);
  return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

function formatCurrency(n) {
  return '₹' + Math.abs(n).toLocaleString('en-IN');
}

function showToast(msg, duration = 2500) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), duration);
}

function initials(name) {
  return name.trim().split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2);
}

// ══ NAVIGATION ══
function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  
  // Handle global nav visibility
  const globalNav = document.getElementById('global-nav');
  if (id === 'login-screen' || id === 'detail-screen') {
    globalNav.style.display = 'none';
  } else {
    globalNav.style.display = 'flex';
  }

  // Update bottom nav active state
  document.querySelectorAll('.nav-item').forEach(item => item.classList.remove('active'));
  if (id === 'dashboard-screen') document.getElementById('nav-dashboard').classList.add('active');
  if (id === 'ledger-screen') document.getElementById('nav-ledger').classList.add('active');
  if (id === 'settings-screen') document.getElementById('nav-settings').classList.add('active');
  if (id === 'profile-screen') document.getElementById('nav-profile').classList.add('active');

  if (id === 'dashboard-screen') renderDashboard();
  if (id === 'ledger-screen') renderLedger();
  if (id === 'settings-screen') renderSettings();
  if (id === 'profile-screen') renderProfile();
  
  window.scrollTo(0, 0);
}

function goBack() { showScreen('ledger-screen'); }

function updateShopUI() {
  const shop = state.shopName;
  ['dash-shop', 'ledger-shop', 'settings-shop', 'profile-shop'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.textContent = shop;
  });
}

// ══ LOGIN ══
function doLogin() {
  const pin = document.getElementById('pin-input').value.trim();
  const shop = document.getElementById('shop-name').value.trim() || 'Grama-Khata';
  if (pin !== state.pin) { showToast('❌ Wrong PIN. Try ' + state.pin); return; }
  state.shopName = shop;
  save();
  updateShopUI();
  showScreen('dashboard-screen');
}

function doLogout() {
  showScreen('login-screen');
}

// ══ DASHBOARD (New Analytics View) ══
function renderDashboard() {
  const totalDue = state.customers.reduce((s, c) => {
    const b = getBalance(c.id);
    return b > 0 ? s + b : s;
  }, 0);
  
  const totalCollectedThisMonth = state.transactions
    .filter(t => t.type === 'take' && daysSince(t.ts) <= 30)
    .reduce((s, t) => s + t.amount, 0);
    
  const totalGiveThisMonth = state.transactions
    .filter(t => t.type === 'give' && daysSince(t.ts) <= 30)
    .reduce((s, t) => s + t.amount, 0);

  const activeDuesCount = state.customers.filter(c => getBalance(c.id) > 0).length;
  
  const overdueCustomers = state.customers
    .map(c => ({ ...c, lastTx: getLastTxDate(c.id), bal: getBalance(c.id) }))
    .filter(c => c.bal > 0 && daysSince(c.lastTx) > 7)
    .sort((a, b) => b.bal - a.bal);

  const dashContent = document.getElementById('dashboard-content');
  dashContent.innerHTML = `
    <div class="dash-card">
      <h3>Collection Overview</h3>
      <div style="display:flex; justify-content:space-between; align-items:center">
        <div>
          <div class="label" style="font-size:0.65rem">Total Outstanding</div>
          <div class="value" style="color:var(--red); font-size:1.8rem">${formatCurrency(totalDue)}</div>
        </div>
        <div style="text-align:right">
          <div class="label" style="font-size:0.65rem">Active Dues</div>
          <div class="value">${activeDuesCount}</div>
        </div>
      </div>
    </div>

    <div class="dash-card">
      <h3>Monthly Collection Goal</h3>
      <div style="display:flex; justify-content:space-between; font-size:0.8rem">
        <span>Collected: ${formatCurrency(totalCollectedThisMonth)}</span>
        <span style="color:var(--gray)">Goal: ${formatCurrency(totalDue + totalCollectedThisMonth)}</span>
      </div>
      <div class="progress-container">
        <div class="progress-bar" style="width: ${Math.min(100, (totalCollectedThisMonth / (totalDue + totalCollectedThisMonth || 1)) * 100)}%"></div>
      </div>
      <p style="font-size:0.7rem; color:var(--gray)">Collect older dues to improve your cash flow!</p>
    </div>

    <div class="dash-card">
      <h3>Weekly Activity</h3>
      <div class="bar-chart">
        ${[6,5,4,3,2,1,0].map(d => {
          const dayAmt = state.transactions
            .filter(t => t.type === 'take' && daysSince(t.ts) === d)
            .reduce((s, t) => s + t.amount, 0);
          const maxAmt = 5000; // Reference for scaling
          const h = Math.min(100, (dayAmt / maxAmt) * 100);
          return `
            <div class="bar-col">
              <div class="bar-fill ${d === 0 ? 'active' : ''}" style="height:${h}%"></div>
              <div class="bar-label">${d === 0 ? 'Today' : (7-d)+'d'}</div>
            </div>
          `;
        }).join('')}
      </div>
    </div>

    <div class="dash-card">
      <h3>⚠️ High Priority Dues</h3>
      ${overdueCustomers.slice(0, 3).map(c => `
        <div class="alert-item">
          <div class="alert-icon">⏳</div>
          <div class="alert-text">${c.name} owes ${formatCurrency(c.bal)} (${daysSince(c.lastTx)} days)</div>
          <div class="alert-action" onclick="showWaReminder(${c.id})">Remind</div>
        </div>
      `).join('') || '<p style="font-size:0.8rem; color:var(--gray)">No overdue accounts. Good job!</p>'}
    </div>
  `;
}

// ══ LEDGER (Old Dashboard View) ══
function renderLedger() {
  const searchQ = (document.getElementById('search-input').value || '').toLowerCase();
  const sortBy = document.getElementById('sort-select').value;

  let custs = state.customers.map(c => ({
    ...c,
    balance: getBalance(c.id),
    lastTx: getLastTxDate(c.id)
  }));

  if (searchQ) {
    custs = custs.filter(c => c.name.toLowerCase().includes(searchQ) || c.phone.includes(searchQ));
  }

  if (sortBy === 'debt') custs.sort((a, b) => b.balance - a.balance);
  else if (sortBy === 'days') custs.sort((a, b) => daysSince(a.lastTx) - daysSince(b.lastTx));
  else custs.sort((a, b) => a.name.localeCompare(b.name));

  const totalDue = custs.reduce((s, c) => c.balance > 0 ? s + c.balance : s, 0);
  const dueCount = custs.filter(c => c.balance > 0).length;
  const settledCount = custs.filter(c => c.balance <= 0).length;

  document.getElementById('total-due').textContent = formatCurrency(totalDue);
  document.getElementById('due-count').textContent = dueCount + ' customers';
  document.getElementById('total-settled').textContent = settledCount;

  const list = document.getElementById('customer-list');
  if (!custs.length) {
    list.innerHTML = `<div class="empty-state"><div class="emoji">📒</div><p>No customers yet.<br/>Tap <strong>＋</strong> to add your first customer!</p></div>`;
    return;
  }

  list.innerHTML = custs.map((c, i) => {
    const isDebt = c.balance > 0;
    const days = daysSince(c.lastTx);
    const daysText = days === 999 ? 'No transactions' : days === 0 ? 'Today' : days === 1 ? 'Yesterday' : `${days} days ago`;
    return `
    <div class="customer-card" style="animation-delay:${i * 0.05}s" onclick="openDetail(${c.id})">
      <div class="avatar">${initials(c.name)}</div>
      <div class="cust-info">
        <div class="name">${c.name}</div>
        <div class="phone">📱 ${c.phone}${c.village ? ' · ' + c.village : ''}</div>
        <span class="days">🕐 ${daysText}</span>
      </div>
      <div class="cust-amt">
        <div class="amount ${isDebt ? 'red' : 'green'}">${formatCurrency(c.balance)}</div>
        <span class="badge ${isDebt ? 'due' : 'settled'}">${isDebt ? 'DUE' : 'SETTLED'}</span>
      </div>
      <div class="cust-actions">
        ${isDebt ? `<button class="wa-btn" onclick="event.stopPropagation();showWaReminder(${c.id})" title="Send WhatsApp reminder">💬</button>` : ''}
      </div>
    </div>`;
  }).join('');
}

// ══ ADD CUSTOMER ══
function openAddCustomer() {
  document.getElementById('new-cust-name').value = '';
  document.getElementById('new-cust-phone').value = '';
  document.getElementById('new-cust-village').value = '';
  openModal('add-customer-modal');
}

function addCustomer() {
  const name = document.getElementById('new-cust-name').value.trim();
  const phone = document.getElementById('new-cust-phone').value.trim();
  const village = document.getElementById('new-cust-village').value.trim();
  if (!name) { showToast('⚠️ Please enter customer name'); return; }
  if (!phone || phone.length < 10) { showToast('⚠️ Enter valid 10-digit phone'); return; }
  const cust = { id: Date.now(), name, phone, village, createdAt: Date.now() };
  state.customers.unshift(cust);
  save();
  closeModal('add-customer-modal');
  renderLedger();
  showToast(`✅ ${name} added to ledger`);
}

// ══ CUSTOMER DETAIL ══
function openDetail(customerId) {
  state.currentCustomerId = customerId;
  const c = state.customers.find(x => x.id === customerId);
  if (!c) return;
  document.getElementById('detail-topbar-name').textContent = c.name;
  renderDetail();
  showScreen('detail-screen');
}

function renderDetail() {
  const c = state.customers.find(x => x.id === state.currentCustomerId);
  if (!c) return;
  const balance = getBalance(c.id);
  const isDebt = balance > 0;
  const txs = state.transactions
    .filter(t => t.customerId === c.id)
    .sort((a, b) => b.ts - a.ts);

  const txHtml = txs.length
    ? txs.map(t => `
      <div class="tx-item">
        <div class="tx-dot ${t.type}">${t.type === 'give' ? '📦' : '💵'}</div>
        <div class="tx-info">
          <div class="tx-note">${t.note || (t.type === 'give' ? 'Items on credit' : 'Payment received')}</div>
          <div class="tx-date">${formatDate(t.ts)}</div>
        </div>
        <div class="tx-amt ${t.type === 'give' ? 'red' : 'green'}">${t.type === 'give' ? '-' : '+'}${formatCurrency(t.amount)}</div>
      </div>`).join('')
    : `<div class="empty-state"><div class="emoji">📋</div><p>No transactions yet.<br/>Use the buttons above to add entries.</p></div>`;

  document.getElementById('detail-content').innerHTML = `
    <div class="cust-header">
      <div class="cust-header-inner">
        <div class="big-avatar">${initials(c.name)}</div>
        <div class="cust-header-info">
          <div class="cname">${c.name}</div>
          <div class="cphone">📱 ${c.phone}${c.village ? ' · ' + c.village : ''}</div>
        </div>
      </div>
    </div>
    <div class="balance-card">
      <div class="bal-label">${isDebt ? '⚠️ Outstanding Balance' : '✅ Account Status'}</div>
      <div class="bal-amount ${isDebt ? 'red' : 'green'}">${formatCurrency(balance)}</div>
      <div class="bal-sub">${isDebt ? `Customer owes you ${formatCurrency(balance)}` : 'All clear — no dues!'}</div>
    </div>
    <div class="action-row">
      <button class="give-btn" onclick="openTxModal('give')">
        📦 Koduvudu
        <span class="tel">Give on Credit</span>
      </button>
      <button class="take-btn" onclick="openTxModal('take')">
        💵 Tegedukolluvudu
        <span class="tel">Receive Payment</span>
      </button>
    </div>
    ${isDebt ? `<div style="margin:0 16px 16px"><button style="width:100%;padding:12px;background:linear-gradient(135deg,#128C7E,#25D366);color:#fff;border:none;border-radius:12px;font-family:var(--font);font-size:.9rem;font-weight:600;cursor:pointer" onclick="showWaReminder(${c.id})">💬 Send WhatsApp Reminder</button></div>` : ''}
    <div class="section-title">Transaction History (${txs.length})</div>
    <div class="tx-list">${txHtml}</div>`;
}

// ══ TRANSACTION MODAL ══
function openTxModal(type) {
  state.txType = type;
  document.getElementById('tx-amount').value = '';
  document.getElementById('tx-note').value = '';
  document.getElementById('tx-preview').style.display = 'none';
  const c = state.customers.find(x => x.id === state.currentCustomerId);
  document.getElementById('tx-modal-title').textContent =
    type === 'give' ? `📦 Koduvudu — Give on Credit` : `💵 Tegedukolluvudu — Receive Payment`;
  const btn = document.getElementById('tx-submit-btn');
  btn.style.background = type === 'give'
    ? 'linear-gradient(135deg,#C62828,#E53935)'
    : 'linear-gradient(135deg,#1B5E20,#2E7D32)';
  openModal('tx-modal');

  document.getElementById('tx-amount').addEventListener('input', updateTxPreview);
  document.getElementById('tx-note').addEventListener('input', updateTxPreview);
}

function updateTxPreview() {
  const amt = parseFloat(document.getElementById('tx-amount').value);
  if (!amt || amt <= 0) { document.getElementById('tx-preview').style.display = 'none'; return; }
  const note = document.getElementById('tx-note').value.trim();
  const c = state.customers.find(x => x.id === state.currentCustomerId);
  const newBal = getBalance(c.id) + (state.txType === 'give' ? amt : -amt);
  const msg = buildWaMessage(c, amt, state.txType, note, newBal);
  document.getElementById('tx-preview').textContent = msg;
  document.getElementById('tx-preview').style.display = 'block';
}

function submitTransaction() {
  const amt = parseFloat(document.getElementById('tx-amount').value);
  const note = document.getElementById('tx-note').value.trim();
  if (!amt || amt <= 0) { showToast('⚠️ Enter a valid amount'); return; }
  const tx = { id: Date.now(), customerId: state.currentCustomerId, amount: amt, type: state.txType, note, ts: Date.now() };
  state.transactions.push(tx);
  save();
  closeModal('tx-modal');
  renderDetail();
  renderLedger();
  showToast(state.txType === 'give' ? `📦 ₹${amt} credit recorded` : `💵 ₹${amt} payment recorded`);
}

// ══ WHATSAPP ══
function buildWaMessage(cust, amount, type, note, newBalance) {
  const shop = state.shopName;
  const date = new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
  if (type === 'give') {
    return `🙏 Namaste ${cust.name} ji!\n\n📦 *${shop}* — New Entry\nDate: ${date}\nItems: ${note || 'Credit purchase'}\nAmount: ₹${amount}\n\n💰 Total Due: *₹${Math.max(0, newBalance)}*\n\nPlease pay when convenient. Thank you! 🙏`;
  } else {
    return `🙏 Namaste ${cust.name} ji!\n\n✅ *${shop}* — Payment Received\nDate: ${date}\nAmount Paid: ₹${amount}\n\n💰 Remaining Balance: *₹${Math.max(0, newBalance)}*\n\nThank you for your payment! 🌿`;
  }
}

function buildReminderMessage(cust) {
  const bal = getBalance(cust.id);
  const lastTx = getLastTxDate(cust.id);
  const days = daysSince(lastTx);
  return `🙏 Namaste ${cust.name} ji,\n\nThis is a gentle reminder from *${state.shopName}*.\n\nYour current outstanding balance is:\n💰 *${formatCurrency(bal)}*\n\nLast transaction: ${formatDate(lastTx)} (${days} days ago)\n\nPlease pay at your earliest convenience.\n\nFor any queries, feel free to contact us.\n\nDhanyavad 🙏🌿`;
}

let waTargetPhone = '';
let waTargetMessage = '';

function showWaReminder(customerId) {
  const c = state.customers.find(x => x.id === customerId);
  if (!c) return;
  waTargetPhone = c.phone;
  waTargetMessage = buildReminderMessage(c);
  document.getElementById('wa-message-text').textContent = waTargetMessage;
  openModal('wa-modal');
}

function sendWhatsApp() {
  const phone = '91' + waTargetPhone.replace(/\D/g, '').slice(-10);
  const msg = encodeURIComponent(waTargetMessage);
  window.open(`https://wa.me/${phone}?text=${msg}`, '_blank');
  closeModal('wa-modal');
  showToast('💬 Opening WhatsApp…');
}

function openReminders() {
  const dues = state.customers.filter(c => getBalance(c.id) > 0);
  if (!dues.length) { showToast('🎉 No pending dues!'); return; }
  showToast(`🔔 ${dues.length} reminders to send — tap 💬 on each`);
}

// ══ SETTINGS ══
function renderSettings() {
  document.getElementById('settings-shop-name').value = state.shopName;
  document.getElementById('settings-pin').value = state.pin;
}

function saveSettings() {
  const shop = document.getElementById('settings-shop-name').value.trim();
  const pin = document.getElementById('settings-pin').value.trim();
  if (!shop) { showToast('⚠️ Shop name cannot be empty'); return; }
  if (pin.length !== 4) { showToast('⚠️ PIN must be 4 digits'); return; }
  
  state.shopName = shop;
  state.pin = pin;
  save();
  updateShopUI();
  showToast('✅ Settings saved');
}

function confirmClearData() {
  if (confirm('⚠️ Are you sure? This will delete ALL customers and transactions permanently!')) {
    state.customers = [];
    state.transactions = [];
    save();
    showScreen('dashboard-screen');
    showToast('🗑️ All data cleared');
  }
}

// ══ PROFILE ══
function renderProfile() {
  const totalDue = state.customers.reduce((s, c) => {
    const b = getBalance(c.id);
    return b > 0 ? s + b : s;
  }, 0);
  const totalReceived = state.transactions
    .filter(t => t.type === 'take')
    .reduce((s, t) => s + t.amount, 0);
  
  const profileDiv = document.getElementById('profile-content');
  profileDiv.innerHTML = `
    <div style="text-align: center; margin-bottom: 24px;">
      <div class="big-avatar" style="margin: 0 auto 12px; background: var(--green); border: none;">${initials(state.shopName)}</div>
      <h2 style="font-size: 1.4rem;">${state.shopName}</h2>
      <p style="color: var(--gray); font-size: 0.9rem;">Village Merchant Profile</p>
    </div>
    
    <div class="stat-card" style="margin-bottom: 12px; display: flex; justify-content: space-between; align-items: center;">
      <div>
        <div class="label">Total Customers</div>
        <div class="value" style="font-size: 1.2rem;">${state.customers.length}</div>
      </div>
      <div>
        <div class="label">Active Dues</div>
        <div class="value" style="font-size: 1.2rem; color: var(--red);">${state.customers.filter(c => getBalance(c.id) > 0).length}</div>
      </div>
    </div>
    
    <div class="stat-card" style="margin-bottom: 12px;">
      <div class="label">Net Outstanding</div>
      <div class="value" style="color: var(--red);">${formatCurrency(totalDue)}</div>
    </div>
    
    <div class="stat-card" style="margin-bottom: 24px;">
      <div class="label">Total Payments Collected</div>
      <div class="value" style="color: var(--green);">${formatCurrency(totalReceived)}</div>
    </div>
    
    <button class="btn-secondary" style="width: 100%;" onclick="doLogout()">Logout from Session</button>
  `;
}

// ══ DELETE CUSTOMER ══
function deleteCurrentCustomer() {
  const c = state.customers.find(x => x.id === state.currentCustomerId);
  if (!c) return;
  if (!confirm(`Delete ${c.name} and all their transactions?`)) return;
  state.customers = state.customers.filter(x => x.id !== state.currentCustomerId);
  state.transactions = state.transactions.filter(t => t.customerId !== state.currentCustomerId);
  save();
  renderLedger();
  goBack();
  showToast(`🗑️ ${c.name} removed from ledger`);
}

// ══ MODAL UTILS ══
function openModal(id) {
  document.getElementById(id).classList.add('open');
}
function closeModal(id) {
  document.getElementById(id).classList.remove('open');
}

// Close modal on backdrop click
document.querySelectorAll('.modal-overlay').forEach(overlay => {
  overlay.addEventListener('click', e => {
    if (e.target === overlay) overlay.classList.remove('open');
  });
});

// ══ INIT ══
load();
updateShopUI();
